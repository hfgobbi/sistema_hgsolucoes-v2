--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Homebrew)
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_Movimentacaos_status_pagamento; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public."enum_Movimentacaos_status_pagamento" AS ENUM (
    'pago',
    'pendente',
    'a_pagar',
    'vencido',
    'cancelado'
);


ALTER TYPE public."enum_Movimentacaos_status_pagamento" OWNER TO herculesgobbi;

--
-- Name: enum_Movimentacaos_tipo; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public."enum_Movimentacaos_tipo" AS ENUM (
    'receita',
    'despesa'
);


ALTER TYPE public."enum_Movimentacaos_tipo" OWNER TO herculesgobbi;

--
-- Name: enum_Movimentacaos_tipo_frequencia; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public."enum_Movimentacaos_tipo_frequencia" AS ENUM (
    'unica',
    'fixa',
    'parcelada'
);


ALTER TYPE public."enum_Movimentacaos_tipo_frequencia" OWNER TO herculesgobbi;

--
-- Name: enum_categorias_tipo; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_categorias_tipo AS ENUM (
    'receita',
    'despesa'
);


ALTER TYPE public.enum_categorias_tipo OWNER TO herculesgobbi;

--
-- Name: enum_movimentacaos_status; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacaos_status AS ENUM (
    'pendente',
    'pago',
    'vencido',
    'cancelado'
);


ALTER TYPE public.enum_movimentacaos_status OWNER TO herculesgobbi;

--
-- Name: enum_movimentacaos_status_pagamento; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacaos_status_pagamento AS ENUM (
    'pago',
    'pendente',
    'a_pagar',
    'vencido',
    'cancelado'
);


ALTER TYPE public.enum_movimentacaos_status_pagamento OWNER TO herculesgobbi;

--
-- Name: enum_movimentacaos_tipo; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacaos_tipo AS ENUM (
    'receita',
    'despesa'
);


ALTER TYPE public.enum_movimentacaos_tipo OWNER TO herculesgobbi;

--
-- Name: enum_movimentacaos_tipo_frequencia; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacaos_tipo_frequencia AS ENUM (
    'unica',
    'fixa',
    'parcelada'
);


ALTER TYPE public.enum_movimentacaos_tipo_frequencia OWNER TO herculesgobbi;

--
-- Name: enum_movimentacoes_status; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacoes_status AS ENUM (
    'pendente',
    'pago',
    'vencido',
    'cancelado'
);


ALTER TYPE public.enum_movimentacoes_status OWNER TO herculesgobbi;

--
-- Name: enum_movimentacoes_tipo; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacoes_tipo AS ENUM (
    'receita',
    'despesa'
);


ALTER TYPE public.enum_movimentacoes_tipo OWNER TO herculesgobbi;

--
-- Name: enum_movimentacoes_tipo_frequencia; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_movimentacoes_tipo_frequencia AS ENUM (
    'unica',
    'diaria',
    'semanal',
    'quinzenal',
    'mensal',
    'anual',
    'fixa',
    'parcelada'
);


ALTER TYPE public.enum_movimentacoes_tipo_frequencia OWNER TO herculesgobbi;

--
-- Name: enum_usuarios_status; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_usuarios_status AS ENUM (
    'ativo',
    'inativo'
);


ALTER TYPE public.enum_usuarios_status OWNER TO herculesgobbi;

--
-- Name: enum_usuarios_tipo; Type: TYPE; Schema: public; Owner: herculesgobbi
--

CREATE TYPE public.enum_usuarios_tipo AS ENUM (
    'admin',
    'usuario'
);


ALTER TYPE public.enum_usuarios_tipo OWNER TO herculesgobbi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Categoria; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public."Categoria" (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    usuario_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public."Categoria" OWNER TO herculesgobbi;

--
-- Name: Categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public."Categoria_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Categoria_id_seq" OWNER TO herculesgobbi;

--
-- Name: Categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public."Categoria_id_seq" OWNED BY public."Categoria".id;


--
-- Name: Movimentacaos; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public."Movimentacaos" (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(10,2) NOT NULL,
    tipo character varying(255) NOT NULL,
    data date NOT NULL,
    observacao text,
    tipo_frequencia character varying(255),
    usuario_id integer NOT NULL,
    categoria_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL,
    data_vencimento date,
    status_pagamento public.enum_movimentacaos_status_pagamento DEFAULT 'pendente'::public.enum_movimentacaos_status_pagamento NOT NULL,
    data_pagamento date,
    parcelas_total integer,
    parcela_atual integer,
    movimentacao_pai_id integer
);


ALTER TABLE public."Movimentacaos" OWNER TO herculesgobbi;

--
-- Name: Movimentacaos_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public."Movimentacaos_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Movimentacaos_id_seq" OWNER TO herculesgobbi;

--
-- Name: Movimentacaos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public."Movimentacaos_id_seq" OWNED BY public."Movimentacaos".id;


--
-- Name: Usuarios; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public."Usuarios" (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    login character varying(255) NOT NULL,
    senha character varying(255) NOT NULL,
    data_nascimento date NOT NULL,
    saldo numeric(10,2),
    admin boolean,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public."Usuarios" OWNER TO herculesgobbi;

--
-- Name: Usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public."Usuarios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Usuarios_id_seq" OWNER TO herculesgobbi;

--
-- Name: Usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public."Usuarios_id_seq" OWNED BY public."Usuarios".id;


--
-- Name: categoria; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.categoria (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    usuario_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public.categoria OWNER TO herculesgobbi;

--
-- Name: categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.categoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_id_seq OWNER TO herculesgobbi;

--
-- Name: categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.categoria_id_seq OWNED BY public.categoria.id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    usuario_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public.categorias OWNER TO herculesgobbi;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_id_seq OWNER TO herculesgobbi;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: contas; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.contas (
    id integer NOT NULL,
    nome character varying(255),
    saldo numeric(10,2),
    tipo character varying(255),
    usuario_id integer,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.contas OWNER TO herculesgobbi;

--
-- Name: contas_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.contas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contas_id_seq OWNER TO herculesgobbi;

--
-- Name: contas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.contas_id_seq OWNED BY public.contas.id;


--
-- Name: movimentacaos; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.movimentacaos (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(10,2) NOT NULL,
    tipo public.enum_movimentacaos_tipo NOT NULL,
    data date NOT NULL,
    observacao text,
    tipo_frequencia public.enum_movimentacaos_tipo_frequencia DEFAULT 'unica'::public.enum_movimentacaos_tipo_frequencia,
    usuario_id integer NOT NULL,
    categoria_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public.movimentacaos OWNER TO herculesgobbi;

--
-- Name: movimentacaos_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.movimentacaos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movimentacaos_id_seq OWNER TO herculesgobbi;

--
-- Name: movimentacaos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.movimentacaos_id_seq OWNED BY public.movimentacaos.id;


--
-- Name: movimentacoes; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.movimentacoes (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(10,2) NOT NULL,
    tipo text NOT NULL,
    data timestamp with time zone NOT NULL,
    observacao text,
    tipo_frequencia text DEFAULT 'unica'::text,
    status text DEFAULT 'pendente'::text,
    data_vencimento timestamp with time zone,
    data_pagamento timestamp with time zone,
    valor_pago numeric(10,2),
    lembrete_ativo boolean DEFAULT false,
    dias_lembrete integer DEFAULT 3,
    recorrente boolean DEFAULT false,
    parcela_atual integer,
    total_parcelas integer,
    movimentacao_pai_id integer,
    usuario_id integer NOT NULL,
    categoria_id integer NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public.movimentacoes OWNER TO herculesgobbi;

--
-- Name: movimentacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.movimentacoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movimentacoes_id_seq OWNER TO herculesgobbi;

--
-- Name: movimentacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.movimentacoes_id_seq OWNED BY public.movimentacoes.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: herculesgobbi
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    login character varying(255) NOT NULL,
    senha character varying(255) NOT NULL,
    data_nascimento timestamp with time zone NOT NULL,
    saldo numeric(10,2) DEFAULT 0,
    admin boolean DEFAULT false,
    data_criacao timestamp with time zone NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


ALTER TABLE public.usuarios OWNER TO herculesgobbi;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: herculesgobbi
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO herculesgobbi;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: herculesgobbi
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: Categoria id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Categoria" ALTER COLUMN id SET DEFAULT nextval('public."Categoria_id_seq"'::regclass);


--
-- Name: Movimentacaos id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Movimentacaos" ALTER COLUMN id SET DEFAULT nextval('public."Movimentacaos_id_seq"'::regclass);


--
-- Name: Usuarios id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Usuarios" ALTER COLUMN id SET DEFAULT nextval('public."Usuarios_id_seq"'::regclass);


--
-- Name: categoria id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id SET DEFAULT nextval('public.categoria_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: contas id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.contas ALTER COLUMN id SET DEFAULT nextval('public.contas_id_seq'::regclass);


--
-- Name: movimentacaos id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacaos ALTER COLUMN id SET DEFAULT nextval('public.movimentacaos_id_seq'::regclass);


--
-- Name: movimentacoes id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacoes ALTER COLUMN id SET DEFAULT nextval('public.movimentacoes_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: Categoria; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public."Categoria" (id, descricao, usuario_id, data_criacao, data_atualizacao) FROM stdin;
6	Lazer	1	2025-06-30 08:42:06.475-04	2025-06-30 08:42:06.475-04
9	Outros	1	2025-06-30 08:42:06.518-04	2025-06-30 08:42:06.518-04
10	Material	1	2025-06-30 08:59:08.378-04	2025-06-30 08:59:08.378-04
11	Serviços	1	2025-06-30 10:29:33.575-04	2025-06-30 10:29:33.575-04
12	Serviços - M.Obra	1	2025-06-30 10:29:55.198-04	2025-06-30 10:29:55.198-04
13	Despesas Administrativas	1	2025-06-30 10:45:53.586-04	2025-06-30 10:45:53.586-04
14	Carro (Empresa)	1	2025-06-30 10:55:15.111-04	2025-06-30 10:55:15.111-04
15	Marketing	1	2025-06-30 11:01:35.376-04	2025-06-30 11:01:35.376-04
16	Pro-Labore	1	2025-06-30 12:27:22.469-04	2025-06-30 12:27:22.469-04
18	Produção (Uautelas)	1	2025-06-30 12:39:38.518-04	2025-06-30 12:39:38.518-04
19	Produção (HG Solucoes)	1	2025-06-30 12:39:54.071-04	2025-06-30 12:39:54.071-04
27	Moradia	1	2025-07-03 13:36:01.522-04	2025-07-03 13:36:01.522-04
28	Alimentação	1	2025-07-03 13:36:01.657-04	2025-07-03 13:36:01.657-04
29	Transporte	1	2025-07-03 13:36:01.671-04	2025-07-03 13:36:01.671-04
30	Saúde	1	2025-07-03 13:36:01.706-04	2025-07-03 13:36:01.706-04
31	Educação	1	2025-07-03 13:36:01.72-04	2025-07-03 13:36:01.72-04
32	Salário	1	2025-07-03 13:36:01.762-04	2025-07-03 13:36:01.762-04
33	Freelance	1	2025-07-03 13:36:01.786-04	2025-07-03 13:36:01.786-04
34	HG - Empresa / Outras Contas	1	2025-07-04 07:48:47.953-04	2025-07-04 07:48:47.953-04
\.


--
-- Data for Name: Movimentacaos; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public."Movimentacaos" (id, descricao, valor, tipo, data, observacao, tipo_frequencia, usuario_id, categoria_id, data_criacao, data_atualizacao, data_vencimento, status_pagamento, data_pagamento, parcelas_total, parcela_atual, movimentacao_pai_id) FROM stdin;
184	Pafemac - Distribuidora	112.00	despesa	2025-07-01		unica	1	10	2025-07-01 14:40:56.218-04	2025-07-01 14:40:56.218-04	2025-07-01	pago	2025-07-01	\N	\N	\N
178	Felipe Gauna	235.00	despesa	2025-07-02		unica	1	12	2025-07-01 13:24:18.727-04	2025-07-02 08:16:35.844-04	2025-07-01	pago	2025-07-02	\N	\N	\N
186	Serviços realizados	1629.52	receita	2025-07-01		unica	1	18	2025-07-02 08:19:02.479-04	2025-07-02 08:19:02.479-04	2025-07-01	pago	2025-07-02	\N	\N	\N
191	Retorno Capital - Compra Ganchos para Cliente	84.00	despesa	2025-07-02	esqueceu de enviar os ganchos junto com material para corumba	unica	1	10	2025-07-02 14:27:33.681-04	2025-07-02 14:27:33.681-04	2025-07-02	pago	2025-07-02	\N	\N	\N
196	Felipe Gauna	185.00	despesa	2025-07-02		unica	1	12	2025-07-02 18:33:31.49-04	2025-07-02 18:33:31.49-04	2025-07-02	pago	2025-07-02	\N	\N	\N
201	Passaletti - Calcado Helo	114.00	despesa	2025-07-02	cartao passaletti. parcelado.	unica	1	16	2025-07-02 18:36:49.512-04	2025-07-02 18:36:49.512-04	2025-07-02	pago	2025-07-02	\N	\N	\N
206	Internet Fibra - Casa	120.00	despesa	2025-06-29		parcelada	1	16	2025-07-02 18:49:46.019-04	2025-07-02 18:49:54.077-04	2025-06-29	pago	2025-07-02	\N	\N	\N
209	Mercado	61.68	despesa	2025-07-03		unica	1	16	2025-07-03 10:57:56.815-04	2025-07-03 10:58:27.847-04	2025-07-02	pago	2025-07-03	\N	\N	\N
214	Serviços Realizados (Gabriel-Felipe)	648.44	receita	2025-07-03		unica	1	18	2025-07-03 11:10:10.137-04	2025-07-03 11:10:10.137-04	2025-07-03	a_pagar	\N	\N	\N	\N
218	Gabriel Duque (Lucro /HG)	300.00	despesa	2025-07-03	emprestou conta bet365.. grupo	unica	1	34	2025-07-04 07:45:38.032-04	2025-07-04 08:05:38.913-04	2025-07-02	pago	2025-07-04	\N	\N	\N
223	Outras Rendas /BET365 - Pagar Gabriel	300.00	receita	2025-07-03	conta** sem lucro	unica	1	19	2025-07-04 08:07:32.18-04	2025-07-04 08:07:52.916-04	2025-07-03	a_pagar	\N	\N	\N	\N
228	Almoço (Mercado)	37.37	despesa	2025-07-04		unica	1	12	2025-07-04 12:02:07.955-04	2025-07-04 12:02:07.955-04	2025-07-04	pago	2025-07-04	\N	\N	\N
233	Deyu - Fabrica	586.60	despesa	2025-09-20	parc3	unica	1	10	2025-07-04 19:58:19.042-04	2025-07-04 19:58:19.042-04	2025-09-22	a_pagar	\N	\N	\N	\N
238	Deyu - Fabrica	1319.85	despesa	2025-10-11	parc4	unica	1	10	2025-07-04 20:01:39.369-04	2025-07-04 20:01:39.369-04	2025-10-16	a_pagar	\N	\N	\N	\N
245	Serviços realizados - Felipe	571.34	receita	2025-07-05		unica	1	34	2025-07-05 18:04:17.628-04	2025-07-05 18:04:17.628-04	2025-07-05	a_pagar	\N	\N	\N	\N
251	Despesas (mercado-almoco)	139.95	despesa	2025-07-05		unica	1	16	2025-07-05 18:08:47.647-04	2025-07-05 18:08:47.647-04	2025-07-05	pago	2025-07-05	\N	\N	\N
243	Serviços realizados - Felipe/Gabriel	523.28	receita	2025-07-04		unica	1	18	2025-07-04 20:12:24.71-04	2025-07-05 18:17:45.462-04	2025-07-03	a_pagar	\N	\N	\N	\N
255	Despesas (padaria)	25.00	despesa	2025-07-05		unica	1	16	2025-07-06 17:07:41.113-04	2025-07-06 17:07:41.113-04	2025-07-05	pago	2025-07-06	\N	\N	\N
260	Combustível - Carro	50.00	despesa	2025-07-06		unica	1	14	2025-07-07 14:51:29.835-04	2025-07-07 14:51:29.835-04	2025-07-06	pago	2025-07-07	\N	\N	\N
25	Alumetal - Distribuidora	5947.00	despesa	2025-01-01		unica	1	10	2025-06-30 10:11:34.925-04	2025-06-30 10:11:34.925-04	2025-01-01	pago	2025-01-01	\N	\N	\N
179	Gabriel Duque	135.00	despesa	2025-07-02		unica	1	12	2025-07-01 13:24:46.835-04	2025-07-02 08:17:15.852-04	2025-07-01	pago	2025-07-02	\N	\N	\N
97	GoogleADS	1611.00	despesa	2024-12-30		unica	1	15	2025-06-30 11:08:28.924-04	2025-06-30 11:08:28.924-04	2024-12-30	pago	2024-12-30	\N	\N	\N
98	GoogleADS	1654.00	despesa	2025-01-05		unica	1	15	2025-06-30 11:08:45.783-04	2025-06-30 11:08:45.783-04	2025-01-05	pago	2025-01-05	\N	\N	\N
99	GoogleADS	3519.00	despesa	2025-02-05		unica	1	15	2025-06-30 11:09:12.651-04	2025-06-30 11:09:12.651-04	2025-02-05	pago	2025-02-05	\N	\N	\N
100	GoogleADS	1699.00	despesa	2025-03-05		unica	1	15	2025-06-30 11:09:30.114-04	2025-06-30 11:09:30.114-04	2025-03-05	pago	2025-03-05	\N	\N	\N
101	GoogleADS	1390.00	despesa	2025-04-05		unica	1	15	2025-06-30 11:09:50.144-04	2025-06-30 11:09:50.144-04	2025-04-05	pago	2025-04-05	\N	\N	\N
102	GoogleADS	1509.43	despesa	2025-04-05		unica	1	15	2025-06-30 11:11:26.043-04	2025-06-30 11:11:26.043-04	2025-04-05	pago	2025-04-05	\N	\N	\N
103	GoogleADS	1247.69	despesa	2025-05-01		unica	1	15	2025-06-30 11:11:44.958-04	2025-06-30 11:11:44.958-04	2025-05-01	pago	2025-05-01	\N	\N	\N
104	GoogleADS	1845.06	despesa	2025-06-05		unica	1	15	2025-06-30 11:12:02.772-04	2025-06-30 11:12:02.772-04	2025-06-05	pago	2025-06-05	\N	\N	\N
105	HospedagemSite Uautelas	42.00	despesa	2024-12-30		unica	1	15	2025-06-30 11:13:42.916-04	2025-06-30 11:13:42.916-04	2024-12-30	pago	2024-12-30	\N	\N	\N
106	HospedagemSite Uautelas	42.00	despesa	2025-01-05		unica	1	15	2025-06-30 11:14:00.04-04	2025-06-30 11:14:00.04-04	2025-01-05	pago	2025-01-05	\N	\N	\N
107	HospedagemSite Uautelas	42.00	despesa	2025-02-05		unica	1	15	2025-06-30 11:14:44.012-04	2025-06-30 11:14:44.012-04	2025-02-05	pago	2025-02-05	\N	\N	\N
108	HospedagemSite Uautelas	42.00	despesa	2025-03-05		unica	1	15	2025-06-30 11:15:07.3-04	2025-06-30 11:15:07.3-04	2025-03-05	pago	2025-03-05	\N	\N	\N
109	HospedagemSite Uautelas	42.00	despesa	2025-04-05		unica	1	15	2025-06-30 11:15:19.252-04	2025-06-30 11:15:19.252-04	2025-04-05	pago	2025-04-05	\N	\N	\N
110	HospedagemSite Uautelas	42.00	despesa	2025-05-05		unica	1	6	2025-06-30 11:15:34.868-04	2025-06-30 11:15:34.868-04	2025-05-05	pago	2025-05-05	\N	\N	\N
111	HospedagemSite Uautelas	42.00	despesa	2025-06-05		unica	1	15	2025-06-30 11:15:53.446-04	2025-06-30 11:15:53.446-04	2025-06-05	pago	2025-06-05	\N	\N	\N
112	Material - Outros	1549.00	despesa	2024-12-30		unica	1	10	2025-06-30 11:20:09.861-04	2025-06-30 11:20:09.861-04	2024-12-30	pago	2024-12-30	\N	\N	\N
113	Material - Outros	1437.00	despesa	2025-01-05		unica	1	10	2025-06-30 11:21:07.046-04	2025-06-30 11:21:07.046-04	2025-01-05	pago	2025-01-05	\N	\N	\N
114	Material - Outros	4384.00	despesa	2025-02-05		unica	1	10	2025-06-30 11:22:04.356-04	2025-06-30 11:22:04.356-04	2025-02-05	pago	2025-02-05	\N	\N	\N
115	Material - Outros	2267.00	despesa	2025-03-05		unica	1	10	2025-06-30 11:22:45.378-04	2025-06-30 11:22:45.378-04	2025-03-05	pago	2025-03-05	\N	\N	\N
116	Material - Outros	4370.00	despesa	2025-04-05		unica	1	10	2025-06-30 11:23:27.993-04	2025-06-30 11:23:27.993-04	2025-04-05	pago	2025-04-05	\N	\N	\N
117	Material - Outros	2904.00	despesa	2025-05-04		unica	1	10	2025-06-30 11:24:16.656-04	2025-06-30 11:24:36.54-04	2025-05-04	pago	2025-05-04	\N	\N	\N
118	Material - Outros	1311.00	despesa	2025-06-05		unica	1	10	2025-06-30 11:25:19.469-04	2025-06-30 11:25:19.469-04	2025-06-05	pago	2025-06-05	\N	\N	\N
119	M.Obra - Outros	1900.00	despesa	2024-12-30		unica	1	12	2025-06-30 11:26:20.741-04	2025-06-30 11:26:20.741-04	2024-12-30	pago	2024-12-30	\N	\N	\N
120	M.Obra - Outros	850.00	despesa	2025-01-05		unica	1	12	2025-06-30 11:26:51.511-04	2025-06-30 11:26:51.511-04	2025-01-05	pago	2025-01-05	\N	\N	\N
121	M.Obra - Outros	3128.00	despesa	2025-02-05		unica	1	12	2025-06-30 11:27:19.671-04	2025-06-30 11:27:19.671-04	2025-02-05	pago	2025-02-05	\N	\N	\N
122	M.Obra - Outros	4220.00	despesa	2025-03-05		unica	1	12	2025-06-30 11:27:46.479-04	2025-06-30 11:27:46.479-04	2025-03-05	pago	2025-03-05	\N	\N	\N
123	M.Obra - Outros	235.00	despesa	2025-04-05		unica	1	12	2025-06-30 11:28:16.808-04	2025-06-30 11:28:16.808-04	2025-04-05	pago	2025-04-05	\N	\N	\N
124	M.Obra - Outros	135.00	despesa	2025-05-05		unica	1	12	2025-06-30 11:28:32.227-04	2025-06-30 11:28:32.227-04	2025-05-05	pago	2025-05-05	\N	\N	\N
146	Outras Despesas - Geral	11590.00	despesa	2025-01-05		unica	1	16	2025-06-30 12:35:34.154-04	2025-06-30 12:35:34.154-04	2025-01-05	pago	2025-01-05	\N	\N	\N
147	Outras Despesas - Geral	11825.00	despesa	2025-02-05		unica	1	16	2025-06-30 12:36:01.942-04	2025-06-30 12:36:01.942-04	2025-02-05	pago	2025-02-05	\N	\N	\N
148	Outras Despesas - Geral	13953.00	despesa	2025-03-05		unica	1	16	2025-06-30 12:36:36.315-04	2025-06-30 12:36:36.315-04	2025-03-05	pago	2025-03-05	\N	\N	\N
149	Outras Despesas - Geral	12928.00	despesa	2025-04-05		unica	1	16	2025-06-30 12:36:59.941-04	2025-06-30 12:36:59.941-04	2025-04-05	pago	2025-04-05	\N	\N	\N
150	Outras Despesas - Geral	12622.00	despesa	2025-05-05		unica	1	16	2025-06-30 12:37:19.838-04	2025-06-30 12:37:19.838-04	2025-05-05	pago	2025-05-05	\N	\N	\N
151	Outras Despesas - Geral	7422.00	despesa	2025-06-05		unica	1	16	2025-06-30 12:38:39.351-04	2025-06-30 12:38:39.351-04	2025-06-05	pago	2025-06-05	\N	\N	\N
192	Refeicao - Servicos	59.00	despesa	2025-07-02	almoco felipe + gabriel	unica	1	12	2025-07-02 14:29:01.567-04	2025-07-02 14:29:01.567-04	2025-07-02	pago	2025-07-02	\N	\N	\N
185	Almoço (Mercado)	59.24	despesa	2025-07-02	Compra para fazer almoco . Funcionarios	unica	1	12	2025-07-01 15:12:40.346-04	2025-07-02 14:33:45.067-04	2025-07-01	pago	2025-07-01	\N	\N	\N
187	Material realizados - Everton	80.00	receita	2025-07-01		unica	1	18	2025-07-02 08:19:52.115-04	2025-07-02 14:34:14.682-04	2025-06-30	pago	2025-07-02	\N	\N	\N
197	Gabriel Duque	135.00	despesa	2025-07-02		unica	1	12	2025-07-02 18:34:06.136-04	2025-07-02 18:34:06.136-04	2025-07-02	pago	2025-07-02	\N	\N	\N
207	Taxas Condominio Afranio - Junho	480.00	despesa	2025-06-11		unica	1	16	2025-07-02 18:59:54.953-04	2025-07-02 19:01:19.798-04	2025-06-10	a_pagar	\N	\N	\N	\N
210	Combustivel	50.00	despesa	2025-07-03		unica	1	14	2025-07-03 10:59:03.888-04	2025-07-03 10:59:03.888-04	2025-07-03	pago	2025-07-03	\N	\N	\N
202	Deyu - Fabrica	630.00	despesa	2025-08-05		unica	1	10	2025-07-02 18:41:08.963-04	2025-07-03 11:00:52.373-04	2025-08-05	a_pagar	\N	\N	\N	\N
215	Serviços realizados - Felipe/Gabriel	300.00	receita	2025-07-03		unica	1	18	2025-07-03 15:51:35.536-04	2025-07-03 15:51:35.536-04	2025-07-03	pago	2025-07-03	\N	\N	\N
219	Licença Aplicativo - Windsurf (Loester)	225.51	despesa	2025-07-03	usei cartao sams club. loester ja tinha passado este valor.. lucro de outras rendas	unica	1	34	2025-07-04 07:48:02.573-04	2025-07-04 07:49:38.739-04	2025-07-02	pago	2025-07-04	\N	\N	\N
224	Energia Conta - Apto no Cond. Afranio	228.00	despesa	2025-06-10		unica	1	16	2025-07-04 08:12:26.37-04	2025-07-04 08:12:26.37-04	2025-06-10	a_pagar	\N	\N	\N	\N
229	Serviços realizados - Felipe/Gabriel	1007.16	receita	2025-07-04		unica	1	18	2025-07-04 12:03:03.606-04	2025-07-04 12:03:03.606-04	2025-07-04	a_pagar	\N	\N	\N	\N
234	Deyu - Fabrica	586.61	despesa	2025-07-20	parc1	unica	1	10	2025-07-04 19:58:58.507-04	2025-07-04 19:58:58.507-04	2025-07-24	a_pagar	\N	\N	\N	\N
239	Deyu - Fabrica	1319.87	despesa	2025-09-11	parc3	unica	1	10	2025-07-04 20:02:05.681-04	2025-07-04 20:02:05.681-04	2025-09-16	a_pagar	\N	\N	\N	\N
247	Despesas (coisas-patricia)	66.00	despesa	2025-07-05		unica	1	16	2025-07-05 18:05:28.932-04	2025-07-05 18:05:28.932-04	2025-07-05	pago	2025-07-05	\N	\N	\N
252	Despesas (uber-patricia)	7.15	despesa	2025-07-05		unica	1	16	2025-07-05 18:09:15.799-04	2025-07-05 18:09:15.799-04	2025-07-05	pago	2025-07-05	\N	\N	\N
244	Serviços realizados - Felipe/Gabriel	545.00	receita	2025-07-04		unica	1	18	2025-07-04 20:15:48.162-04	2025-07-05 18:16:59.283-04	2025-07-03	pago	2025-07-05	\N	\N	\N
256	Despesas (mercado-almoco)	75.59	despesa	2025-07-05		unica	1	16	2025-07-06 17:08:24.243-04	2025-07-06 17:08:24.243-04	2025-07-05	pago	2025-07-06	\N	\N	\N
257	Felipe Gauna (bet365)	300.00	despesa	2025-07-05		unica	1	34	2025-07-06 17:09:44.112-04	2025-07-06 17:09:44.112-04	2025-07-05	pago	2025-07-06	\N	\N	\N
211	Internet Fibra - Casa	120.00	despesa	2025-07-20		parcelada	1	16	2025-07-03 11:06:36.003-04	2025-07-03 11:06:36.003-04	2025-07-31	a_pagar	\N	\N	\N	\N
230	Combustível - Carro	50.00	despesa	2025-07-04		unica	1	14	2025-07-04 12:04:01.485-04	2025-07-04 12:04:01.485-04	2025-07-04	pago	2025-07-04	\N	\N	\N
188	GoogleADS	324.36	despesa	2025-07-02	***usei cartao neon	unica	1	15	2025-07-02 08:22:55.437-04	2025-07-02 08:22:55.437-04	2025-07-02	pago	2025-07-02	\N	\N	\N
193	Carro - Combustivel	50.00	despesa	2025-07-02		unica	1	14	2025-07-02 14:30:02.897-04	2025-07-02 14:30:02.897-04	2025-07-02	pago	2025-07-02	\N	\N	\N
198	Serviços realizados	799.00	receita	2025-07-02		unica	1	18	2025-07-02 18:34:57.711-04	2025-07-02 18:34:57.711-04	2025-07-02	a_pagar	\N	\N	\N	\N
180	Combustível - Carro	50.00	despesa	2025-07-01		unica	1	14	2025-07-01 13:26:12.34-04	2025-07-01 13:26:21.827-04	\N	pago	2025-07-01	\N	\N	\N
10	Metalurgica Verdadeira - Fabrica	583.00	despesa	2025-07-01		unica	1	10	2025-06-30 10:00:01.243-04	2025-07-01 13:26:31.057-04	2025-07-01	pago	2025-07-01	\N	\N	\N
12	Deyu - Fabrica	631.00	despesa	2025-07-03		unica	1	10	2025-06-30 10:01:14.986-04	2025-07-04 08:04:57.695-04	2025-07-02	pago	2025-07-02	\N	\N	\N
216	Almoço (Mercado)	61.00	despesa	2025-07-03		unica	1	12	2025-07-03 15:52:47.483-04	2025-07-03 15:52:47.483-04	2025-07-03	pago	2025-07-03	\N	\N	\N
11	Deyu - Fabrica	995.00	despesa	2025-07-25		unica	1	10	2025-06-30 10:00:47.149-04	2025-07-04 08:01:59.356-04	2025-07-24	a_pagar	\N	\N	\N	\N
13	Deyu - Fabrica	817.00	despesa	2025-07-25		unica	1	10	2025-06-30 10:01:40.378-04	2025-07-04 08:02:22.696-04	2025-07-24	a_pagar	\N	\N	\N	\N
225	Internet Conta - Apto no Cond. Afranio	120.00	despesa	2025-06-29		unica	1	16	2025-07-04 08:12:51.426-04	2025-07-04 08:12:51.426-04	2025-06-29	a_pagar	\N	\N	\N	\N
220	Felipe Gauna	185.00	despesa	2025-07-04		unica	1	12	2025-07-04 07:54:42.302-04	2025-07-04 16:57:43.851-04	2025-07-04	pago	2025-07-04	\N	\N	\N
235	Deyu - Fabrica	586.61	despesa	2025-08-20	parc2	unica	1	10	2025-07-04 19:59:37.653-04	2025-07-04 19:59:37.653-04	2025-08-25	a_pagar	\N	\N	\N	\N
157	Serviços/Material realizados	19320.00	receita	2025-04-04		unica	1	18	2025-06-30 12:44:20.049-04	2025-06-30 12:45:02.329-04	2025-04-04	pendente	\N	\N	\N	\N
248	Despesas (uber-patricia)	26.39	despesa	2025-07-05		unica	1	16	2025-07-05 18:06:12.432-04	2025-07-05 18:06:12.432-04	2025-07-05	pago	2025-07-05	\N	\N	\N
253	Despesas (uber-patricia)	27.68	despesa	2025-07-05		unica	1	16	2025-07-05 18:09:36.592-04	2025-07-05 18:09:36.592-04	2025-07-05	pago	2025-07-05	\N	\N	\N
240	Mercado - Outros	137.66	despesa	2025-07-04		unica	1	16	2025-07-04 20:04:24.674-04	2025-07-05 18:21:18.734-04	2025-07-03	pago	2025-07-05	\N	\N	\N
26	Alumetal - Distribuidora	4872.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:11:56.609-04	2025-06-30 10:11:56.609-04	2025-02-01	pago	2025-02-01	\N	\N	\N
27	Alumetal - Distribuidora	5420.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:12:16.546-04	2025-06-30 10:12:16.546-04	2025-03-01	pago	2025-03-01	\N	\N	\N
28	Alumetal - Distribuidora	1583.00	despesa	2025-04-01		unica	1	10	2025-06-30 10:12:41.453-04	2025-06-30 10:12:41.453-04	2025-04-01	pago	2025-04-01	\N	\N	\N
29	Alumetal - Distribuidora	1594.00	despesa	2025-05-01		unica	1	10	2025-06-30 10:12:59.182-04	2025-06-30 10:12:59.182-04	2025-05-01	pago	2025-05-01	\N	\N	\N
30	Alumetal - Distribuidora	3159.00	despesa	2025-06-01		unica	1	10	2025-06-30 10:13:19.96-04	2025-06-30 10:13:19.96-04	2025-06-01	pago	2025-06-01	\N	\N	\N
31	Deyu - Fabrica	770.00	despesa	2025-06-01	frete (entrega de material)	unica	1	10	2025-06-30 10:14:51.326-04	2025-06-30 10:14:51.326-04	2025-06-01	pago	2025-06-01	\N	\N	\N
32	Deyu - Fabrica	497.00	despesa	2025-04-01	frete (material)	unica	1	10	2025-06-30 10:15:34.079-04	2025-06-30 10:15:34.079-04	2025-04-01	pago	2025-04-01	\N	\N	\N
33	Deyu - Fabrica	934.00	despesa	2025-02-01	frete (material)	unica	1	10	2025-06-30 10:16:10.144-04	2025-06-30 10:16:10.144-04	2025-02-01	pago	2025-02-01	\N	\N	\N
34	Deyu - Fabrica	195.00	despesa	2024-12-30	frete (material)	unica	1	10	2025-06-30 10:16:29.925-04	2025-06-30 10:16:29.925-04	2024-12-30	pago	2024-12-30	\N	\N	\N
35	Catumbi - Fabrica	260.00	despesa	2024-12-30		unica	1	10	2025-06-30 10:17:36.377-04	2025-06-30 10:17:36.377-04	2024-12-30	pago	2024-12-30	\N	\N	\N
36	Catumbi - Fabrica	260.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:17:54-04	2025-06-30 10:17:54-04	2025-02-01	pago	2025-02-01	\N	\N	\N
37	PerfilFerros - Distribuidora	399.00	despesa	2024-12-30		unica	1	10	2025-06-30 10:18:59.735-04	2025-06-30 10:18:59.735-04	2024-12-30	pago	2024-12-30	\N	\N	\N
38	PerfilFerros - Distribuidora	2334.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:19:23.067-04	2025-06-30 10:19:23.067-04	2025-02-01	pago	2025-02-01	\N	\N	\N
39	PerfilFerros - Distribuidora	408.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:19:40.924-04	2025-06-30 10:19:40.924-04	2025-03-01	pago	2025-03-01	\N	\N	\N
40	PerfilFerros - Distribuidora	538.00	despesa	2025-04-01		unica	1	10	2025-06-30 10:20:02.743-04	2025-06-30 10:20:02.743-04	2025-04-01	pago	2025-04-01	\N	\N	\N
41	PerfilFerros - Distribuidora	330.00	despesa	2025-05-01		unica	1	10	2025-06-30 10:20:26.156-04	2025-06-30 10:20:26.156-04	2025-05-01	pago	2025-05-01	\N	\N	\N
42	Pafemac - Distribuidora	120.00	despesa	2024-12-30		unica	1	10	2025-06-30 10:21:31.673-04	2025-06-30 10:21:31.673-04	2024-12-30	pago	2024-12-30	\N	\N	\N
43	Pafemac - Distribuidora	185.00	despesa	2025-01-01		unica	1	10	2025-06-30 10:21:58.216-04	2025-06-30 10:21:58.216-04	2025-01-01	pago	2025-01-01	\N	\N	\N
44	Pafemac - Distribuidora	283.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:22:25.337-04	2025-06-30 10:22:25.337-04	2025-03-01	pago	2025-03-01	\N	\N	\N
45	Pafemac - Distribuidora	125.00	despesa	2025-04-01		unica	1	10	2025-06-30 10:22:49.44-04	2025-06-30 10:22:49.44-04	2025-04-01	pago	2025-04-01	\N	\N	\N
46	Juros - Mateiral	1530.00	despesa	2024-12-30		unica	1	10	2025-06-30 10:24:09.691-04	2025-06-30 10:24:09.691-04	2024-12-30	pago	2024-12-30	\N	\N	\N
47	Juros - Mateiral	500.00	despesa	2025-01-01		unica	1	10	2025-06-30 10:24:39.45-04	2025-06-30 10:24:39.45-04	2025-01-01	pago	2025-01-01	\N	\N	\N
48	Juros - Mateiral	465.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:25:01.555-04	2025-06-30 10:25:01.555-04	2025-02-01	pago	2025-02-01	\N	\N	\N
49	Juros - Mateiral	1084.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:25:30.677-04	2025-06-30 10:25:30.677-04	2025-03-01	pago	2025-03-01	\N	\N	\N
50	Juros - Mateiral	213.00	despesa	2025-04-01		unica	1	10	2025-06-30 10:26:18.107-04	2025-06-30 10:26:18.107-04	2025-04-01	pago	2025-04-01	\N	\N	\N
51	Juros - Mateiral	325.00	despesa	2025-05-01		unica	1	10	2025-06-30 10:26:33.425-04	2025-06-30 10:26:33.425-04	2025-05-01	pago	2025-05-01	\N	\N	\N
52	Juros - Mateiral	500.00	despesa	2025-06-01		unica	1	10	2025-06-30 10:26:52.457-04	2025-06-30 10:26:52.457-04	2025-06-01	pago	2025-06-01	\N	\N	\N
53	Felipe Gauna	4530.00	despesa	2024-12-30		unica	1	12	2025-06-30 10:30:56.541-04	2025-06-30 10:30:56.541-04	2024-12-30	pago	2024-12-30	\N	\N	\N
54	Felipe Gauna	5825.00	despesa	2025-01-01		unica	1	12	2025-06-30 10:31:20.669-04	2025-06-30 10:39:51.904-04	2025-01-01	pago	2025-01-01	\N	\N	\N
55	Felipe Gauna	6068.00	despesa	2025-02-01		unica	1	12	2025-06-30 10:31:58.925-04	2025-06-30 10:44:30.685-04	2025-02-01	pago	2025-02-01	\N	\N	\N
208	Taxas Condominio Afranio - Junho	480.00	despesa	2025-07-20		unica	1	34	2025-07-02 19:00:33.97-04	2025-07-11 21:10:58.105-04	2025-07-09	a_pagar	\N	\N	\N	\N
56	Felipe Gauna	4507.00	despesa	2025-03-01		unica	1	12	2025-06-30 10:32:31.328-04	2025-06-30 10:47:48.014-04	2025-03-01	pago	2025-03-01	\N	\N	\N
57	Felipe Gauna	3300.00	despesa	2025-04-01		unica	1	12	2025-06-30 10:32:55.314-04	2025-06-30 10:42:21.16-04	2025-04-01	pago	2025-04-01	\N	\N	\N
58	Felipe Gauna	3235.00	despesa	2025-05-01		unica	1	12	2025-06-30 10:33:42.506-04	2025-06-30 10:42:02.895-04	2025-05-01	pago	2025-05-01	\N	\N	\N
60	Gabriel Duque	1900.00	despesa	2025-04-01		unica	1	12	2025-06-30 10:37:32.629-04	2025-06-30 10:43:32.772-04	2025-04-01	pago	2025-04-01	\N	\N	\N
61	Gabriel Duque	1690.00	despesa	2025-05-01		unica	1	12	2025-06-30 10:37:59.069-04	2025-06-30 10:37:59.069-04	2025-05-01	pago	2025-05-01	\N	\N	\N
63	Plano Cel Uautelas	51.00	despesa	2024-12-01		parcelada	1	13	2025-06-30 10:46:31.863-04	2025-06-30 10:46:31.863-04	2024-12-01	pago	2024-12-01	\N	\N	\N
64	Plano Cel Uautelas	51.00	despesa	2025-01-01		unica	1	13	2025-06-30 10:46:59.572-04	2025-06-30 10:46:59.572-04	2025-01-01	pago	2025-01-01	\N	\N	\N
65	Plano Cel Uautelas	51.00	despesa	2025-02-01		unica	1	13	2025-06-30 10:47:19.697-04	2025-06-30 10:47:19.697-04	2025-02-01	pago	2025-02-01	\N	\N	\N
66	Plano Cel Uautelas	51.00	despesa	2025-03-01		unica	1	13	2025-06-30 10:48:26.524-04	2025-06-30 10:48:26.524-04	2025-03-01	pago	2025-03-01	\N	\N	\N
67	Plano Cel Uautelas	51.00	despesa	2025-04-01		unica	1	13	2025-06-30 10:48:50.903-04	2025-06-30 10:48:50.903-04	2025-04-01	pago	2025-04-01	\N	\N	\N
68	Plano Cel Uautelas	51.00	despesa	2025-05-01		unica	1	13	2025-06-30 10:49:10.613-04	2025-06-30 10:49:10.613-04	2025-05-01	pago	2025-05-01	\N	\N	\N
69	Plano Cel Uautelas	51.00	despesa	2025-06-01		unica	1	13	2025-06-30 10:49:35.411-04	2025-06-30 10:49:35.411-04	2025-06-01	pago	2025-06-01	\N	\N	\N
70	MEI Uautelas	292.00	despesa	2024-12-30		unica	1	13	2025-06-30 10:51:19.267-04	2025-06-30 10:51:19.267-04	2024-12-30	pago	2024-12-30	\N	\N	\N
71	MEI Uautelas	270.00	despesa	2025-01-01		unica	1	13	2025-06-30 10:51:41.306-04	2025-06-30 10:51:41.306-04	2025-01-01	pago	2025-01-01	\N	\N	\N
72	MEI Uautelas	52.00	despesa	2025-02-05		unica	1	13	2025-06-30 10:52:03.715-04	2025-06-30 10:52:03.715-04	2025-02-05	pago	2025-02-05	\N	\N	\N
73	MEI Uautelas	52.00	despesa	2025-03-05		unica	1	13	2025-06-30 10:52:20.029-04	2025-06-30 10:52:20.029-04	2025-03-05	pago	2025-03-05	\N	\N	\N
74	MEI Uautelas	276.00	despesa	2025-04-05		unica	1	13	2025-06-30 10:52:48.705-04	2025-06-30 10:52:48.705-04	2025-04-05	pago	2025-04-05	\N	\N	\N
75	MEI Uautelas	279.00	despesa	2025-05-05		unica	1	13	2025-06-30 10:53:17.011-04	2025-06-30 10:53:17.011-04	2025-05-05	pago	2025-05-05	\N	\N	\N
76	Carro - SomaDespesas	2852.00	despesa	2024-12-30		unica	1	14	2025-06-30 10:56:16.217-04	2025-06-30 10:56:16.217-04	2024-12-30	pago	2024-12-30	\N	\N	\N
77	Carro - SomaDespesas	2592.00	despesa	2025-01-05		unica	1	14	2025-06-30 10:56:51.406-04	2025-06-30 10:56:51.406-04	2025-01-05	pago	2025-01-05	\N	\N	\N
78	Carro - SomaDespesas	6293.00	despesa	2025-02-05		unica	1	14	2025-06-30 10:57:23.243-04	2025-06-30 10:57:23.243-04	2025-02-05	pago	2025-02-05	\N	\N	\N
79	Carro - SomaDespesas	4581.00	despesa	2025-03-05		unica	1	14	2025-06-30 10:58:00.462-04	2025-06-30 10:58:00.462-04	2025-03-05	pago	2025-03-05	\N	\N	\N
80	Carro - SomaDespesas	4934.00	despesa	2025-04-05		unica	1	14	2025-06-30 10:58:31.704-04	2025-06-30 10:58:31.704-04	2025-04-05	pago	2025-04-05	\N	\N	\N
81	Carro - SomaDespesas	3054.00	despesa	2025-05-05		unica	1	14	2025-06-30 10:58:55.618-04	2025-06-30 10:58:55.618-04	2025-05-05	pago	2025-05-05	\N	\N	\N
83	Seguro de Vida - Sicoob	147.00	despesa	2024-12-30		unica	1	15	2025-06-30 11:02:10.193-04	2025-06-30 11:02:10.193-04	2024-12-30	pago	2024-12-30	\N	\N	\N
84	Seguro de Vida - Sicoob	147.00	despesa	2025-01-01		unica	1	15	2025-06-30 11:02:27.18-04	2025-06-30 11:02:27.18-04	2025-01-01	pago	2025-01-01	\N	\N	\N
85	Seguro de Vida - Sicoob	147.00	despesa	2025-02-05		unica	1	15	2025-06-30 11:02:40.749-04	2025-06-30 11:02:40.749-04	2025-02-05	pago	2025-02-05	\N	\N	\N
86	Seguro de Vida - Sicoob	147.00	despesa	2025-03-05		unica	1	15	2025-06-30 11:02:54.126-04	2025-06-30 11:02:54.126-04	2025-03-05	pago	2025-03-05	\N	\N	\N
87	Seguro de Vida - Sicoob	161.00	despesa	2025-04-05		unica	1	15	2025-06-30 11:03:20.392-04	2025-06-30 11:03:20.392-04	2025-04-05	pago	2025-04-05	\N	\N	\N
88	Seguro de Vida - Sicoob	161.00	despesa	2025-05-05		unica	1	15	2025-06-30 11:03:34.566-04	2025-06-30 11:03:34.566-04	2025-05-05	pago	2025-05-05	\N	\N	\N
89	Seguro de Vida - Sicoob	161.00	despesa	2025-06-04		unica	1	15	2025-06-30 11:03:49.661-04	2025-06-30 11:04:20.063-04	2025-06-04	pago	2025-06-04	\N	\N	\N
90	MetaAds	439.00	despesa	2024-12-30		unica	1	15	2025-06-30 11:05:14.073-04	2025-06-30 11:05:14.073-04	2024-12-30	pago	2024-12-30	\N	\N	\N
91	meta	273.00	despesa	2025-01-01		unica	1	15	2025-06-30 11:05:32.025-04	2025-06-30 11:05:32.025-04	2025-01-01	pago	2025-01-01	\N	\N	\N
92	MetaAds	124.00	despesa	2025-02-05		unica	1	15	2025-06-30 11:05:52.424-04	2025-06-30 11:05:52.424-04	2025-02-05	pago	2025-02-05	\N	\N	\N
93	MetaAds	220.00	despesa	2025-03-05		unica	1	15	2025-06-30 11:06:24.872-04	2025-06-30 11:06:24.872-04	2025-03-05	pago	2025-03-05	\N	\N	\N
94	MetaAds	430.00	despesa	2025-04-05		unica	1	15	2025-06-30 11:06:45.296-04	2025-06-30 11:06:45.296-04	2025-04-05	pago	2025-04-05	\N	\N	\N
95	MetaAds	260.00	despesa	2025-05-05		unica	1	15	2025-06-30 11:07:04.218-04	2025-06-30 11:07:04.218-04	2025-05-05	pago	2025-05-05	\N	\N	\N
96	MetaAds	71.00	despesa	2025-06-05		unica	1	15	2025-06-30 11:07:19.491-04	2025-06-30 11:07:19.491-04	2025-06-05	pago	2025-06-05	\N	\N	\N
62	Gabriel Duque	2070.00	despesa	2025-06-03		unica	1	12	2025-06-30 10:38:19.322-04	2025-07-01 12:43:48.959-04	2025-06-01	pago	2025-06-03	\N	\N	\N
169	OUTRAS RENDAS	2179.00	receita	2025-05-05		unica	1	19	2025-06-30 12:55:26.26-04	2025-07-01 12:37:09.867-04	2025-05-05	pago	2025-05-05	\N	\N	\N
59	Felipe Gauna	2810.00	despesa	2025-06-28		unica	1	12	2025-06-30 10:34:04.508-04	2025-07-01 12:43:07.78-04	2025-06-01	pago	2025-06-28	\N	\N	\N
1	Deyu - Fabrica	4285.00	despesa	2024-12-30		unica	1	10	2025-06-30 09:00:48.38-04	2025-06-30 09:00:48.38-04	2024-12-30	pago	2024-12-30	\N	\N	\N
2	Deyu - Fabrica	3575.00	despesa	2025-01-01		unica	1	10	2025-06-30 09:01:26.006-04	2025-06-30 09:51:49.335-04	2025-01-01	pago	2025-01-01	\N	\N	\N
3	Deyu - Fabrica	5345.00	despesa	2025-02-01		unica	1	10	2025-06-30 09:01:52.96-04	2025-06-30 09:53:01.485-04	2025-02-01	pago	2025-02-01	\N	\N	\N
4	Deyu - Fabrica	1824.00	despesa	2025-03-01		unica	1	10	2025-06-30 09:02:20.482-04	2025-06-30 09:53:19.835-04	2025-03-01	pago	2025-03-01	\N	\N	\N
5	Deyu - Fabrica	4081.00	despesa	2025-05-01		unica	1	10	2025-06-30 09:02:44.653-04	2025-06-30 09:54:42.71-04	2025-05-01	pago	2025-05-01	\N	\N	\N
6	Deyu - Fabrica	2819.00	despesa	2025-04-01		unica	1	10	2025-06-30 09:03:57.049-04	2025-06-30 09:53:56.895-04	2025-04-01	pago	2025-04-01	\N	\N	\N
7	Deyu - Fabrica	4267.00	despesa	2025-06-01		unica	1	10	2025-06-30 09:55:29.518-04	2025-06-30 09:55:29.518-04	2025-06-01	pago	2025-06-01	\N	\N	\N
8	Metalurgica Verdadeira - Fabrica	693.00	despesa	2025-05-01	=1749,09/3 + 110	unica	1	10	2025-06-30 09:58:30.837-04	2025-06-30 09:58:30.837-04	2025-05-01	pago	2025-05-01	\N	\N	\N
9	Metalurgica Verdadeira - Fabrica	583.00	despesa	2025-06-01		unica	1	10	2025-06-30 09:59:12.457-04	2025-06-30 09:59:12.457-04	2025-06-01	pago	2025-06-01	\N	\N	\N
14	Textil - Fabrica	3070.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:04:19.579-04	2025-06-30 10:04:19.579-04	2025-02-01	pago	2025-02-01	\N	\N	\N
15	Textil - Fabrica	8205.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:04:50.484-04	2025-06-30 10:04:50.484-04	2025-03-01	pago	2025-03-01	\N	\N	\N
16	Textil - Fabrica	548.00	despesa	2025-04-01		unica	1	6	2025-06-30 10:05:26.237-04	2025-06-30 10:05:26.237-04	2025-04-01	pago	2025-04-01	\N	\N	\N
17	Mauax - Fabrica	412.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:06:38.22-04	2025-06-30 10:06:38.22-04	2025-02-01	pago	2025-02-01	\N	\N	\N
18	Mauax - Fabrica	1737.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:07:02.304-04	2025-06-30 10:07:02.304-04	2025-03-01	pago	2025-03-01	\N	\N	\N
19	Kalon Adesivas - Fabrica	181.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:07:43.767-04	2025-06-30 10:07:43.767-04	2025-02-01	pago	2025-02-01	\N	\N	\N
20	Kalon Adesivas - Fabrica	1117.00	despesa	2025-03-01		unica	1	10	2025-06-30 10:08:07.738-04	2025-06-30 10:08:07.738-04	2025-03-01	pago	2025-03-01	\N	\N	\N
21	Kalon Adesivas - Fabrica	181.00	despesa	2025-04-01		unica	1	10	2025-06-30 10:08:33.942-04	2025-06-30 10:08:33.942-04	2025-04-01	pago	2025-04-01	\N	\N	\N
22	NRArtefatos - Fabrica	1404.00	despesa	2024-12-30	s/frete	unica	1	10	2025-06-30 10:09:56.077-04	2025-06-30 10:09:56.077-04	2024-12-30	pago	2024-12-30	\N	\N	\N
23	NRArtefatos - Fabrica	1357.00	despesa	2025-02-01		unica	1	10	2025-06-30 10:10:19.779-04	2025-06-30 10:10:19.779-04	2025-02-01	pago	2025-02-01	\N	\N	\N
24	Alumetal - Distribuidora	5934.00	despesa	2024-12-30		unica	1	10	2025-06-30 10:11:13.618-04	2025-06-30 10:11:13.618-04	2024-12-30	pago	2024-12-30	\N	\N	\N
82	Carro - SomaDespesas	1834.00	despesa	2025-06-05	Manutenção + Combustivel	unica	1	14	2025-06-30 11:00:06.999-04	2025-07-01 13:28:05.34-04	2025-06-05	pago	2025-06-05	\N	\N	\N
204	Painel Solar	563.00	despesa	2025-07-30	Financiamento do Painel Solar	parcelada	1	16	2025-07-02 18:47:15.391-04	2025-07-03 10:59:36.874-04	2025-07-28	a_pagar	\N	\N	\N	\N
258	bet365 - cicero pagou felipe	300.00	receita	2025-07-05		unica	1	19	2025-07-06 17:10:42.493-04	2025-07-06 17:10:42.493-04	2025-07-05	a_pagar	\N	\N	\N	\N
212	Felipe Gauna	185.00	despesa	2025-07-03		unica	1	12	2025-07-03 11:08:00.916-04	2025-07-04 07:53:15.133-04	2025-07-03	pago	2025-07-04	\N	\N	\N
194	Despesas - Filhas	55.00	despesa	2025-07-02	Lanche -+ Caderno Criancas	unica	1	16	2025-07-02 14:31:00.273-04	2025-07-02 14:31:00.273-04	2025-07-02	pago	2025-07-02	\N	\N	\N
199	Serviços realizados	795.00	receita	2025-07-02		unica	1	18	2025-07-02 18:35:16.989-04	2025-07-02 18:35:16.989-04	2025-07-02	a_pagar	\N	\N	\N	\N
217	Licença Aplicativo - Windsurf (HG)	164.99	despesa	2025-07-03	usei cartao samsclub	unica	1	34	2025-07-03 17:00:56.359-04	2025-07-04 07:49:11.781-04	2025-07-01	pago	2025-07-03	\N	\N	\N
226	Energia - Casa	84.00	despesa	2025-06-29		parcelada	1	16	2025-07-04 08:13:49.176-04	2025-07-04 08:15:50.103-04	2025-06-28	a_pagar	\N	\N	\N	\N
221	Gabriel Duque	135.00	despesa	2025-07-04		unica	1	12	2025-07-04 07:54:56.06-04	2025-07-04 16:57:45.813-04	2025-07-04	pago	2025-07-04	\N	\N	\N
241	Deyu - Fabrica	1319.00	despesa	2025-08-11		unica	1	10	2025-07-04 20:07:32.643-04	2025-07-04 20:07:32.643-04	2025-07-19	a_pagar	\N	\N	\N	\N
249	Despesas (lanchonete-patricia)	29.00	despesa	2025-07-05		unica	1	16	2025-07-05 18:07:10.08-04	2025-07-05 18:07:10.08-04	2025-07-05	pago	2025-07-05	\N	\N	\N
231	Combustível - Carro (1/2)	50.00	despesa	2025-07-05		parcelada	1	14	2025-07-04 12:30:38.101-04	2025-07-05 18:09:57.148-04	2025-07-05	pago	2025-07-05	2	1	\N
254	Felipe Gauna	135.00	despesa	2025-07-05		unica	1	12	2025-07-05 18:11:20.014-04	2025-07-05 18:11:20.014-04	2025-07-05	pago	2025-07-05	\N	\N	\N
343	Mercado - lanche criancas	52.00	despesa	2025-07-16		unica	1	16	2025-07-16 16:57:14.282-04	2025-07-16 16:57:14.282-04	2025-07-16	pago	2025-07-16	\N	\N	\N
125	ADM.OUTROS	649.00	despesa	2024-12-30		unica	1	13	2025-06-30 11:29:17.745-04	2025-06-30 11:29:17.745-04	2024-12-30	pago	2024-12-30	\N	\N	\N
126	ADM.OUTROS	1950.00	despesa	2025-01-05		unica	1	13	2025-06-30 11:29:47.503-04	2025-06-30 11:29:47.503-04	2025-01-05	pago	2025-01-05	\N	\N	\N
127	ADM.OUTROS	542.00	despesa	2025-02-05		unica	1	13	2025-06-30 11:30:12.495-04	2025-06-30 11:30:12.495-04	2025-02-05	pago	2025-02-05	\N	\N	\N
128	ADM.OUTROS	679.00	despesa	2025-03-05		unica	1	13	2025-06-30 11:30:32.598-04	2025-06-30 11:30:32.598-04	2025-03-05	pago	2025-03-05	\N	\N	\N
129	ADM.OUTROS	718.00	despesa	2025-04-05		unica	1	13	2025-06-30 11:30:57.657-04	2025-06-30 11:30:57.657-04	2025-04-05	pago	2025-04-05	\N	\N	\N
130	ADM.OUTROS	435.00	despesa	2025-05-05		unica	1	13	2025-06-30 11:31:13.976-04	2025-06-30 11:31:13.976-04	2025-05-05	pago	2025-05-05	\N	\N	\N
152	Serviços/Material realizados	44353.00	receita	2024-12-30		unica	1	18	2025-06-30 12:40:54.919-04	2025-06-30 12:40:54.919-04	2024-12-30	pendente	\N	\N	\N	\N
153	Serviços/Material realizados	50534.00	receita	2025-01-05		unica	1	18	2025-06-30 12:42:02.891-04	2025-06-30 12:42:02.891-04	2025-01-05	pendente	\N	\N	\N	\N
154	Serviços/Material realizados	74572.00	receita	2025-02-05		unica	1	18	2025-06-30 12:42:44.52-04	2025-06-30 12:42:44.52-04	2025-02-05	pendente	\N	\N	\N	\N
155	Serviços/Material realizados	56241.00	receita	2025-03-04		unica	1	18	2025-06-30 12:43:30.329-04	2025-06-30 12:54:32.435-04	2025-03-04	pendente	\N	\N	\N	\N
156	Serviços/Material realizados	2907.00	receita	2025-03-04		unica	1	18	2025-06-30 12:43:56.694-04	2025-06-30 12:54:18.237-04	2025-03-04	pendente	\N	\N	\N	\N
158	Serviços/Material realizados	7078.00	receita	2025-04-05		unica	1	18	2025-06-30 12:44:40.501-04	2025-06-30 12:44:40.501-04	2025-04-05	pendente	\N	\N	\N	\N
159	Serviços/Material realizados	23679.00	receita	2025-05-05		unica	1	18	2025-06-30 12:45:31.455-04	2025-06-30 12:45:31.455-04	2025-05-05	pendente	\N	\N	\N	\N
160	Serviços/Material realizados	5297.00	receita	2025-05-05		unica	1	18	2025-06-30 12:45:47.168-04	2025-06-30 12:45:47.168-04	2025-05-05	pendente	\N	\N	\N	\N
161	Serviços/Material realizados	26564.00	receita	2025-06-04		unica	1	18	2025-06-30 12:46:16.153-04	2025-06-30 12:46:26.982-04	2025-06-04	pendente	\N	\N	\N	\N
162	Serviços/Material realizados	4865.00	receita	2025-06-05		unica	1	18	2025-06-30 12:46:42.583-04	2025-06-30 12:47:20.708-04	2025-06-05	pendente	\N	\N	\N	\N
163	OUTRAS RENDAS	3000.00	receita	2025-01-05		unica	1	19	2025-06-30 12:48:19.683-04	2025-06-30 12:48:19.683-04	2025-01-05	pendente	\N	\N	\N	\N
164	OUTRAS RENDAS	974.00	receita	2025-02-05		unica	1	19	2025-06-30 12:48:40.311-04	2025-06-30 12:48:40.311-04	2025-02-05	pendente	\N	\N	\N	\N
165	OUTRAS RENDAS	350.00	receita	2025-03-05		unica	1	19	2025-06-30 12:48:59.017-04	2025-06-30 12:48:59.017-04	2025-03-05	pendente	\N	\N	\N	\N
166	OUTRAS RENDAS	7256.00	receita	2025-04-04		unica	1	18	2025-06-30 12:49:19.643-04	2025-06-30 12:53:22.103-04	2025-04-04	pendente	\N	\N	\N	\N
167	OUTRAS RENDAS	2179.00	receita	2025-06-04		unica	1	19	2025-06-30 12:49:43.947-04	2025-06-30 12:51:44.463-04	2025-06-04	pendente	\N	\N	\N	\N
168	OUTRAS RENDAS	1842.00	receita	2025-06-04		unica	1	19	2025-06-30 12:50:15.277-04	2025-06-30 12:51:56.557-04	2025-06-04	pendente	\N	\N	\N	\N
170	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2024-12-29		unica	1	19	2025-06-30 12:57:33.15-04	2025-06-30 12:57:46.583-04	2024-12-29	pendente	\N	\N	\N	\N
171	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-01-05		unica	1	19	2025-06-30 12:58:04.219-04	2025-06-30 12:58:04.219-04	2025-01-05	pendente	\N	\N	\N	\N
172	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-02-05		unica	1	19	2025-06-30 12:58:18.785-04	2025-06-30 12:58:18.785-04	2025-02-05	pendente	\N	\N	\N	\N
173	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-03-05		unica	1	19	2025-06-30 12:58:31.696-04	2025-06-30 13:00:07.54-04	2025-03-05	pendente	\N	\N	\N	\N
174	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-04-05		unica	1	19	2025-06-30 12:58:44.51-04	2025-06-30 12:59:55.989-04	2025-04-05	pendente	\N	\N	\N	\N
175	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-05-06		unica	1	19	2025-06-30 12:58:58.664-04	2025-06-30 12:58:58.664-04	2025-05-06	pendente	\N	\N	\N	\N
176	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-06-04		unica	1	19	2025-06-30 12:59:11.869-04	2025-06-30 12:59:38.783-04	2025-06-04	pendente	\N	\N	\N	\N
131	ADM.OUTROS	1731.00	despesa	2025-06-04		unica	1	13	2025-06-30 11:31:25.903-04	2025-07-01 13:29:09.433-04	2025-06-04	pago	2025-06-04	\N	\N	\N
259	Denise (Internet)	100.00	receita	2025-07-05		unica	1	34	2025-07-06 17:37:03.926-04	2025-07-06 17:37:03.926-04	2025-07-05	a_pagar	\N	\N	\N	\N
190	Hospedagem - Site Uautelas	41.90	despesa	2025-07-02		unica	1	15	2025-07-02 14:26:11.664-04	2025-07-02 14:26:11.664-04	2025-07-02	pago	2025-07-02	\N	\N	\N
195	Tenis - Isa	69.99	despesa	2025-07-02	compra de tenis para isa	unica	1	16	2025-07-02 14:37:19.486-04	2025-07-02 14:37:19.486-04	2025-07-02	pago	2025-07-02	\N	\N	\N
200	Serviços realizados	605.00	receita	2025-07-01		unica	1	18	2025-07-02 18:35:38.631-04	2025-07-02 18:35:38.631-04	2025-07-02	a_pagar	\N	\N	\N	\N
205	Painel Solar	577.78	despesa	2025-06-29		unica	1	16	2025-07-02 18:48:14.728-04	2025-07-02 18:48:14.728-04	2025-06-29	pago	2025-07-02	\N	\N	\N
213	Gabriel Duque	135.00	despesa	2025-07-03		unica	1	12	2025-07-03 11:08:27.621-04	2025-07-04 07:53:18.105-04	2025-07-03	pago	2025-07-04	\N	\N	\N
222	Mercado - Casa	122.99	despesa	2025-07-03		unica	1	16	2025-07-04 08:04:01.011-04	2025-07-04 08:04:01.011-04	2025-07-03	pago	2025-07-04	\N	\N	\N
227	Celular - Conta Internet HG	66.00	despesa	2025-06-29		unica	1	34	2025-07-04 08:14:33.895-04	2025-07-04 08:14:33.895-04	2025-06-29	a_pagar	\N	\N	\N	\N
242	Deyu - Fabrica	1445.00	despesa	2025-09-11		unica	1	10	2025-07-04 20:08:14.887-04	2025-07-04 20:08:14.887-04	2025-09-16	a_pagar	\N	\N	\N	\N
250	Despesas (helo.patricia)	69.00	despesa	2025-07-05		unica	1	16	2025-07-05 18:08:00.078-04	2025-07-05 18:08:00.078-04	2025-07-05	pago	2025-07-05	\N	\N	\N
132	Marketing - Outros	90.00	despesa	2024-12-30		unica	1	15	2025-06-30 11:32:35.395-04	2025-06-30 11:32:35.395-04	2024-12-30	pago	2024-12-30	\N	\N	\N
133	Marketing - Outros	180.00	despesa	2025-01-05		unica	1	15	2025-06-30 11:33:01.017-04	2025-06-30 11:33:01.017-04	2025-01-05	pago	2025-01-05	\N	\N	\N
134	Marketing - Outros	650.00	despesa	2025-03-05		unica	1	15	2025-06-30 11:33:31.945-04	2025-06-30 11:33:31.945-04	2025-03-05	pago	2025-03-05	\N	\N	\N
135	Marketing - Outros	632.00	despesa	2025-04-05		unica	1	15	2025-06-30 11:34:03.728-04	2025-06-30 11:34:03.728-04	2025-04-05	pago	2025-04-05	\N	\N	\N
136	Marketing - Outros	330.00	despesa	2025-05-05		unica	1	15	2025-06-30 11:34:29.389-04	2025-06-30 11:34:29.389-04	2025-05-05	pago	2025-05-05	\N	\N	\N
137	Marketing - Outros	200.00	despesa	2025-06-05		unica	1	15	2025-06-30 11:34:51.318-04	2025-06-30 11:34:51.318-04	2025-06-05	pago	2025-06-05	\N	\N	\N
138	Parcelamento - Carro	1500.00	despesa	2024-12-30		unica	1	14	2025-06-30 12:29:04.663-04	2025-06-30 12:29:04.663-04	2024-12-30	pago	2024-12-30	\N	\N	\N
139	Parcelamento - Carro	1500.00	despesa	2025-01-05		unica	1	14	2025-06-30 12:29:25.661-04	2025-06-30 12:29:25.661-04	2025-01-05	pago	2025-01-05	\N	\N	\N
140	Parcelamento - Carro	1500.00	despesa	2025-02-05		unica	1	14	2025-06-30 12:29:44.049-04	2025-06-30 12:29:44.049-04	2025-02-05	pago	2025-02-05	\N	\N	\N
182	Seguro de Vida - Sicoob (1/2)	160.00	despesa	2025-07-10		unica	1	15	2025-07-01 14:03:20.06-04	2025-07-11 21:03:58.56-04	2025-07-10	pago	2025-07-12	2	1	\N
342	Gabriel Duque	135.00	despesa	2025-07-16		unica	1	12	2025-07-16 08:55:54.152-04	2025-07-16 16:57:24.663-04	2025-07-16	pago	2025-07-16	\N	\N	\N
141	Parcelamento - Carro	1500.00	despesa	2025-03-05		unica	1	14	2025-06-30 12:29:57.824-04	2025-06-30 12:29:57.824-04	2025-03-05	pago	2025-03-05	\N	\N	\N
142	Parcelamento - Carro	1500.00	despesa	2025-04-05		unica	1	14	2025-06-30 12:30:17.452-04	2025-06-30 12:30:17.452-04	2025-04-05	pago	2025-04-05	\N	\N	\N
143	Parcelamento - Carro	1500.00	despesa	2025-05-05		unica	1	14	2025-06-30 12:30:31.921-04	2025-06-30 12:30:31.921-04	2025-05-05	pago	2025-05-05	\N	\N	\N
144	Parcelamento - Carro	1500.00	despesa	2025-06-05		unica	1	14	2025-06-30 12:30:48.252-04	2025-06-30 12:30:48.252-04	2025-06-05	pago	2025-06-05	\N	\N	\N
145	Outras Despesas - Geral	16097.00	despesa	2024-12-30		unica	1	16	2025-06-30 12:34:58.574-04	2025-06-30 12:34:58.574-04	2024-12-30	pago	2024-12-30	\N	\N	\N
262	Combustivel	50.00	despesa	2025-07-07		unica	1	14	2025-07-07 19:30:53.414-04	2025-07-07 19:30:53.414-04	2025-07-07	pago	2025-07-07	\N	\N	\N
265	Serviços - Gabriel/Felipe	700.00	receita	2025-07-07		unica	1	18	2025-07-07 19:39:32.859-04	2025-07-07 19:39:32.859-04	2025-07-07	a_pagar	\N	\N	\N	\N
266	Material - Everton	134.22	receita	2025-07-07		unica	1	18	2025-07-07 19:40:10.955-04	2025-07-07 19:40:10.955-04	2025-07-07	a_pagar	\N	\N	\N	\N
267	Mercado - Almoco	50.54	despesa	2025-07-07		unica	1	12	2025-07-07 19:41:57.099-04	2025-07-07 19:41:57.099-04	2025-07-07	pago	2025-07-07	\N	\N	\N
268	uber - patricia e isa	50.84	despesa	2025-07-07		unica	1	16	2025-07-07 19:42:46.317-04	2025-07-07 19:42:46.317-04	2025-07-07	pago	2025-07-07	\N	\N	\N
269	medico - isa - dentista	60.00	despesa	2025-07-07		unica	1	16	2025-07-07 19:43:23.918-04	2025-07-07 19:43:23.918-04	2025-07-07	pago	2025-07-07	\N	\N	\N
270	patricia outros 30 + 19	54.00	despesa	2025-07-07		unica	1	16	2025-07-07 19:44:18.275-04	2025-07-07 19:44:18.275-04	2025-07-07	pago	2025-07-07	\N	\N	\N
271	uber - patricia	26.80	despesa	2025-07-07		unica	1	16	2025-07-07 19:45:01.554-04	2025-07-07 19:45:01.554-04	2025-07-07	pago	2025-07-07	\N	\N	\N
272	Serviços - Gabriel/Felipe	620.21	receita	2025-07-07		unica	1	18	2025-07-07 19:46:10.859-04	2025-07-07 19:46:10.859-04	2025-07-07	a_pagar	\N	\N	\N	\N
310	Felipe Gauna	135.00	despesa	2025-07-12		unica	1	12	2025-07-12 08:43:40.447-04	2025-07-17 18:57:29.212-04	2025-07-12	pago	2025-07-17	\N	\N	\N
274	Serviços - Gabriel/Felipe	700.00	receita	2025-07-07		unica	1	18	2025-07-07 19:49:29.066-04	2025-07-07 19:49:29.066-04	2025-07-07	a_pagar	\N	\N	\N	\N
264	Gabriel Duque	135.00	despesa	2025-07-07		unica	1	12	2025-07-07 19:38:05.029-04	2025-07-09 21:12:59.983-04	2025-07-07	pago	2025-07-10	\N	\N	\N
263	Felipe Gauna	185.00	despesa	2025-07-07		unica	1	12	2025-07-07 19:31:27.178-04	2025-07-09 21:13:03.481-04	2025-07-07	pago	2025-07-10	\N	\N	\N
275	Farmacia	126.81	despesa	2025-07-07		unica	1	16	2025-07-09 21:15:26.319-04	2025-07-09 21:15:26.319-04	2025-07-07	pago	2025-07-10	\N	\N	\N
276	Juros de Conta - usando limite estourado	511.39	despesa	2025-07-07		unica	1	13	2025-07-09 21:17:09.138-04	2025-07-09 21:17:09.138-04	2025-07-07	pago	2025-07-10	\N	\N	\N
277	Combustivel	50.00	despesa	2025-07-08		unica	1	14	2025-07-09 21:17:44.683-04	2025-07-09 21:17:44.683-04	2025-07-08	pago	2025-07-10	\N	\N	\N
278	Servicos - Felipe / Gabriel	500.00	receita	2025-07-08		unica	1	18	2025-07-09 21:18:35.51-04	2025-07-09 21:18:35.51-04	2025-07-09	a_pagar	\N	\N	\N	\N
279	SERVICOS - GABRIEL/FELIPE	395.00	receita	2025-07-08		unica	1	18	2025-07-09 21:19:16.343-04	2025-07-09 21:19:16.343-04	2025-07-09	a_pagar	\N	\N	\N	\N
280	SERVICOS - GABRIEL/FELIPE	430.00	receita	2025-07-08		unica	1	18	2025-07-09 21:19:42.802-04	2025-07-09 21:19:42.802-04	2025-07-09	a_pagar	\N	\N	\N	\N
281	SERVICOS - GABRIEL/FELIPE	635.00	receita	2025-07-08		unica	1	18	2025-07-09 21:20:00.926-04	2025-07-09 21:20:00.926-04	2025-07-09	a_pagar	\N	\N	\N	\N
282	Felipe Gauna	185.00	despesa	2025-07-08		unica	1	12	2025-07-09 21:20:28.988-04	2025-07-09 21:21:22.628-04	2025-07-08	pago	2025-07-10	\N	\N	\N
283	Gabriel Duque	135.00	receita	2025-07-08		unica	1	12	2025-07-09 21:21:40.782-04	2025-07-09 21:21:40.782-04	2025-07-09	a_pagar	\N	\N	\N	\N
284	Farmacia	59.01	despesa	2025-07-08		unica	1	16	2025-07-09 21:22:25.257-04	2025-07-09 21:22:25.257-04	2025-07-08	pago	2025-07-10	\N	\N	\N
285	Mercado - Casa	354.25	despesa	2025-07-08		unica	1	16	2025-07-09 21:23:02.595-04	2025-07-09 21:23:02.595-04	2025-07-08	pago	2025-07-10	\N	\N	\N
286	Material - Franca	183.60	receita	2025-07-09		unica	1	18	2025-07-09 21:23:36.794-04	2025-07-09 21:23:36.794-04	2025-07-09	a_pagar	\N	\N	\N	\N
287	Material - Everton	200.00	receita	2025-07-09		unica	1	18	2025-07-09 21:23:51.513-04	2025-07-09 21:23:51.513-04	2025-07-09	a_pagar	\N	\N	\N	\N
288	LAVINIA - AUTOESCOLA	370.00	despesa	2025-07-09		unica	1	34	2025-07-09 21:24:41.324-04	2025-07-09 21:24:41.324-04	2025-07-09	pago	2025-07-10	\N	\N	\N
289	MAE - AJUDA	150.00	despesa	2025-07-09		unica	1	34	2025-07-09 21:25:08.424-04	2025-07-09 21:25:08.424-04	2025-07-09	pago	2025-07-10	\N	\N	\N
290	Combustivel	100.00	despesa	2025-07-09		unica	1	14	2025-07-09 21:25:40.054-04	2025-07-09 21:25:40.054-04	2025-07-09	pago	2025-07-10	\N	\N	\N
291	Mercado - Janta	102.31	despesa	2025-07-09		unica	1	16	2025-07-09 21:26:34.444-04	2025-07-09 21:26:34.444-04	2025-07-09	pago	2025-07-10	\N	\N	\N
292	Felipe Gauna	185.00	despesa	2025-07-10		unica	1	12	2025-07-11 20:59:56.364-04	2025-07-11 20:59:56.364-04	2025-07-10	pago	2025-07-12	\N	\N	\N
293	Patricia - Outros	30.00	despesa	2025-07-10		unica	1	16	2025-07-11 21:00:33.043-04	2025-07-11 21:00:33.043-04	2025-07-10	pago	2025-07-12	\N	\N	\N
294	Mercado -  Outros	14.64	despesa	2025-07-10		unica	1	16	2025-07-11 21:01:32.264-04	2025-07-11 21:01:32.264-04	2025-07-10	pago	2025-07-12	\N	\N	\N
297	Patricia - Outros	1.99	despesa	2025-07-10		unica	1	16	2025-07-11 21:03:15.745-04	2025-07-11 21:03:15.745-04	2025-07-10	pago	2025-07-12	\N	\N	\N
298	Mercado - Janta	54.50	despesa	2025-07-10		unica	1	16	2025-07-11 21:04:55.098-04	2025-07-11 21:04:55.098-04	2025-07-10	pago	2025-07-12	\N	\N	\N
299	Pacote Servicos - Sicoob	110.00	despesa	2025-07-10		unica	1	13	2025-07-11 21:05:45.34-04	2025-07-11 21:05:45.34-04	2025-07-10	pago	2025-07-12	\N	\N	\N
300	Mercado - Outros	37.00	despesa	2025-07-10		unica	1	16	2025-07-11 21:06:18.413-04	2025-07-11 21:06:18.413-04	2025-07-10	pago	2025-07-12	\N	\N	\N
301	Conta Internet - Condominion Afranio apto	115.02	despesa	2025-07-11		unica	1	34	2025-07-11 21:07:28.364-04	2025-07-11 21:07:28.364-04	2025-07-11	pago	2025-07-12	\N	\N	\N
302	Conta Internet - Condominion Afranio apto	109.79	despesa	2025-07-11		unica	1	34	2025-07-11 21:08:02.614-04	2025-07-11 21:08:02.614-04	2025-07-11	pago	2025-07-12	\N	\N	\N
319	Serviços realizados - Felipe/Gabriel	665.00	receita	2025-07-14		unica	1	18	2025-07-15 19:02:22.201-04	2025-07-17 19:11:40.289-04	2025-07-13	pago	2025-07-15	\N	\N	\N
305	Licenca - Sistema HG	231.34	despesa	2025-07-11		unica	1	34	2025-07-11 21:14:21.147-04	2025-07-11 21:14:21.147-04	2025-07-11	pago	2025-07-12	\N	\N	\N
306	Almoco - Felipe /Gabriel	60.00	despesa	2025-07-11		unica	1	12	2025-07-11 21:15:07.124-04	2025-07-11 21:15:07.124-04	2025-07-11	pago	2025-07-12	\N	\N	\N
303	SERVICOS - GABRIEL/FELIPE	1538.72	receita	2025-07-11		unica	1	18	2025-07-11 21:08:41.506-04	2025-07-11 21:16:06.976-04	2025-07-10	pago	2025-07-12	\N	\N	\N
307	Gabriel Duque	200.00	despesa	2025-07-11		unica	1	12	2025-07-11 21:16:31.95-04	2025-07-11 21:16:31.95-04	2025-07-11	pago	2025-07-12	\N	\N	\N
308	Felipe Gauna	335.00	despesa	2025-07-11		unica	1	16	2025-07-11 21:16:48.426-04	2025-07-11 21:16:48.426-04	2025-07-11	pago	2025-07-12	\N	\N	\N
309	Combustivel	50.00	despesa	2025-07-12		unica	1	14	2025-07-12 08:43:12.081-04	2025-07-12 08:43:12.081-04	2025-07-12	pago	2025-07-12	\N	\N	\N
311	SERVICOS - FELIPE	767.25	receita	2025-07-12		unica	1	18	2025-07-12 09:54:06.715-04	2025-07-12 09:54:06.715-04	2025-07-12	a_pagar	\N	\N	\N	\N
312	SALDO HG - BET365	1051.00	receita	2025-07-12	SALDO CICERO	unica	1	34	2025-07-15 18:56:39.65-04	2025-07-15 18:56:39.65-04	2025-07-15	a_pagar	\N	\N	\N	\N
313	Despesas (OUTROS-patricia)	191.00	despesa	2025-07-12		unica	1	16	2025-07-15 18:57:16.639-04	2025-07-15 18:57:16.639-04	2025-07-12	pago	2025-07-15	\N	\N	\N
314	Despesas (LANCHE)	100.00	despesa	2025-07-12		unica	1	16	2025-07-15 18:58:41.09-04	2025-07-15 18:58:41.09-04	2025-07-12	pago	2025-07-15	\N	\N	\N
315	Combustível - Carro	50.00	despesa	2025-07-13		unica	1	14	2025-07-15 18:59:13.28-04	2025-07-15 18:59:13.28-04	2025-07-13	pago	2025-07-15	\N	\N	\N
316	Despesas (uber--outros-patricia)	101.00	despesa	2025-07-13		unica	1	16	2025-07-15 18:59:47.364-04	2025-07-15 18:59:47.364-04	2025-07-13	pago	2025-07-15	\N	\N	\N
317	Combustível - Carro	50.00	despesa	2025-07-14		unica	1	14	2025-07-15 19:01:15.581-04	2025-07-15 19:01:15.581-04	2025-07-14	pago	2025-07-15	\N	\N	\N
318	Serviços realizados - Felipe/Gabriel	434.00	receita	2025-07-14		unica	1	18	2025-07-15 19:01:59.148-04	2025-07-15 19:01:59.148-04	2025-07-15	a_pagar	\N	\N	\N	\N
296	SERVICOS - GABRIEL/FELIPE	615.00	receita	2025-07-10		unica	1	18	2025-07-11 21:02:39.902-04	2025-07-17 19:12:17.68-04	2025-07-09	pago	2025-07-12	\N	\N	\N
295	SERVICOS - GABRIEL/FELIPE	515.00	receita	2025-07-10		unica	1	18	2025-07-11 21:02:13.622-04	2025-07-17 19:12:48.313-04	2025-07-09	pago	2025-07-12	\N	\N	\N
320	Serviços realizados - Felipe/Gabriel	300.00	receita	2025-07-14		unica	1	18	2025-07-15 19:02:46.599-04	2025-07-15 19:02:46.599-04	2025-07-14	a_pagar	\N	\N	\N	\N
321	Serviços realizados - Felipe/Gabriel	767.25	receita	2025-07-12		unica	1	18	2025-07-15 19:03:39.431-04	2025-07-15 19:03:39.431-04	2025-07-12	pago	2025-07-15	\N	\N	\N
322	Alumetal - Materal	806.48	despesa	2025-07-14		unica	1	10	2025-07-15 19:04:21.809-04	2025-07-15 19:04:21.809-04	2025-07-14	pago	2025-07-15	\N	\N	\N
323	Felipe Gauna	185.00	despesa	2025-07-14		unica	1	12	2025-07-15 19:05:12.875-04	2025-07-15 19:05:12.875-04	2025-07-14	pago	2025-07-15	\N	\N	\N
324	Gabriel Duque	135.00	despesa	2025-07-14		unica	1	16	2025-07-15 19:05:38.491-04	2025-07-15 19:05:38.491-04	2025-07-14	pago	2025-07-15	\N	\N	\N
325	Gabriel Duque	300.00	despesa	2025-07-14		unica	1	34	2025-07-15 19:06:04.305-04	2025-07-15 19:06:04.305-04	2025-07-14	pago	2025-07-15	\N	\N	\N
326	BET365	300.00	receita	2025-07-14	PAGAR GABRIEL	unica	1	34	2025-07-15 19:06:36.898-04	2025-07-15 19:06:36.898-04	2025-07-15	a_pagar	\N	\N	\N	\N
327	ADALBERTO - USEI VALOR  GUARDADO (1051)	592.00	despesa	2025-07-14		unica	1	34	2025-07-15 19:07:23.223-04	2025-07-15 19:07:23.223-04	2025-07-14	pago	2025-07-15	\N	\N	\N
328	Despesas (mercado-GAS)	115.00	despesa	2025-07-14		unica	1	16	2025-07-15 19:07:52.218-04	2025-07-15 19:07:52.218-04	2025-07-14	pago	2025-07-15	\N	\N	\N
329	Despesas (mercado-almoco)	72.00	despesa	2025-07-15		unica	1	12	2025-07-15 19:08:24.859-04	2025-07-15 19:08:24.859-04	2025-07-15	pago	2025-07-15	\N	\N	\N
330	Serviços realizados - Felipe/Gabriel	354.33	receita	2025-07-15		unica	1	19	2025-07-15 19:08:46.778-04	2025-07-15 19:08:46.778-04	2025-07-15	a_pagar	\N	\N	\N	\N
332	Serviços realizados - Felipe/Gabriel	557.71	receita	2025-07-15		unica	1	18	2025-07-15 19:09:37.872-04	2025-07-15 19:09:37.872-04	2025-07-15	a_pagar	\N	\N	\N	\N
333	Serviços realizados - Felipe/Gabriel	535.00	receita	2025-07-15		unica	1	18	2025-07-15 19:09:52.687-04	2025-07-15 19:09:52.687-04	2025-07-15	a_pagar	\N	\N	\N	\N
334	Felipe Gauna	185.00	despesa	2025-07-15		unica	1	12	2025-07-15 19:10:08.259-04	2025-07-15 19:10:08.259-04	2025-07-15	pago	2025-07-15	\N	\N	\N
335	Gabriel Duque	135.00	despesa	2025-07-15		unica	1	12	2025-07-15 19:10:29.199-04	2025-07-15 19:10:29.199-04	2025-07-15	pago	2025-07-15	\N	\N	\N
331	Despesas (mercado-lanche criancas)	25.00	despesa	2025-07-14		unica	1	16	2025-07-15 19:09:20.288-04	2025-07-15 19:11:24.189-04	2025-07-14	pago	2025-07-15	\N	\N	\N
336	Combustível - Carro	50.00	despesa	2025-07-15		unica	1	14	2025-07-15 19:12:33.467-04	2025-07-15 19:12:33.467-04	2025-07-15	pago	2025-07-15	\N	\N	\N
337	Despesas (farmacia-patricia)	165.00	despesa	2025-07-15		unica	1	16	2025-07-15 19:13:18.268-04	2025-07-15 19:13:18.268-04	2025-07-15	pago	2025-07-15	\N	\N	\N
338	Despesas (uber-patricia)	16.00	despesa	2025-07-15		unica	1	16	2025-07-15 19:13:57.367-04	2025-07-15 19:13:57.367-04	2025-07-15	pago	2025-07-15	\N	\N	\N
339	Energia - Casa	85.98	despesa	2025-07-15		unica	1	16	2025-07-16 07:45:57.266-04	2025-07-16 07:45:57.266-04	2025-07-15	pago	2025-07-16	\N	\N	\N
340	Energia - Casa	84.35	despesa	2025-07-15		unica	1	16	2025-07-16 07:46:26.61-04	2025-07-16 07:46:26.61-04	2025-07-15	pago	2025-07-16	\N	\N	\N
341	Felipe Gauna	185.00	despesa	2025-07-16		unica	1	12	2025-07-16 08:46:54.738-04	2025-07-16 16:57:29.886-04	2025-07-16	pago	2025-07-16	\N	\N	\N
344	Patricia - Outros - uber	37.00	despesa	2025-07-16		unica	1	16	2025-07-16 16:59:15.912-04	2025-07-16 16:59:15.912-04	2025-07-16	pago	2025-07-16	\N	\N	\N
345	SERVICOS - GABRIEL/FELIPE	505.00	receita	2025-07-16		unica	1	18	2025-07-16 17:01:20.503-04	2025-07-16 17:01:20.503-04	2025-07-16	a_pagar	\N	\N	\N	\N
347	SERVICOS - GABRIEL/FELIPE	190.00	receita	2025-07-16		unica	1	18	2025-07-16 17:01:54.503-04	2025-07-16 17:01:54.503-04	2025-07-16	a_pagar	\N	\N	\N	\N
236	Deyu - Fabrica	1319.87	despesa	2025-07-16	parc1	unica	1	10	2025-07-04 20:00:12.043-04	2025-07-16 17:02:35.33-04	2025-07-17	pago	2025-07-16	\N	\N	\N
367	ADALBERTO (BET365) DIVISAO LUCRO	331.60	despesa	2025-07-19	BET365 43,33+288,27	unica	1	34	2025-07-18 21:03:21.453-04	2025-07-18 21:03:21.453-04	2025-07-19	pago	2025-07-19	\N	\N	\N
189	Frete - Cruzeiro do Sul	66.19	despesa	2025-07-17	****corumba	unica	1	10	2025-07-02 08:28:01.728-04	2025-07-16 17:03:36.382-04	2025-07-18	pago	2025-07-16	\N	\N	\N
348	Material - compra bloca	27.20	despesa	2025-07-16		unica	1	10	2025-07-16 17:06:36.747-04	2025-07-16 17:06:36.747-04	2025-07-16	pago	2025-07-16	\N	\N	\N
349	Felipe Gauna	185.00	despesa	2025-07-17		unica	1	12	2025-07-17 18:58:01.239-04	2025-07-17 18:58:01.239-04	2025-07-17	pago	2025-07-17	\N	\N	\N
350	Gabriel Duque	135.00	despesa	2025-07-17		unica	1	12	2025-07-17 18:58:24.402-04	2025-07-17 18:58:24.402-04	2025-07-17	pago	2025-07-17	\N	\N	\N
351	LOJAS - PASSALETI	252.92	despesa	2025-07-17		unica	1	16	2025-07-17 18:59:39.096-04	2025-07-17 18:59:39.096-04	2025-07-17	pago	2025-07-17	\N	\N	\N
352	PORTAO - CASA MANUTENCAO	220.00	despesa	2025-07-17		unica	1	16	2025-07-17 19:00:06.59-04	2025-07-17 19:00:06.59-04	2025-07-17	pago	2025-07-17	\N	\N	\N
304	Conta Energia - Apto afranio condominio	249.98	despesa	2025-07-17		unica	1	34	2025-07-11 21:10:14.871-04	2025-07-17 19:01:31.666-04	2025-07-16	pago	2025-07-16	\N	\N	\N
353	Combustivel	50.00	despesa	2025-07-17		unica	1	14	2025-07-17 19:01:56.04-04	2025-07-17 19:01:56.04-04	2025-07-17	pago	2025-07-17	\N	\N	\N
354	uber - patricia	14.34	despesa	2025-07-17		unica	1	16	2025-07-17 19:02:40.096-04	2025-07-17 19:02:40.096-04	2025-07-17	pago	2025-07-17	\N	\N	\N
355	CRIANCAS - patricia - BOLSA	50.00	despesa	2025-07-17		unica	1	16	2025-07-17 19:03:06.65-04	2025-07-17 19:03:06.65-04	2025-07-17	pago	2025-07-17	\N	\N	\N
356	SERVICOS - GABRIEL/FELIPE	618.00	receita	2025-07-17		unica	1	18	2025-07-17 19:03:40.202-04	2025-07-17 19:03:40.202-04	2025-07-17	a_pagar	\N	\N	\N	\N
346	SERVICOS - GABRIEL/FELIPE	290.00	receita	2025-07-16		unica	1	19	2025-07-16 17:01:36.403-04	2025-07-17 19:04:05.667-04	2025-07-15	a_pagar	\N	\N	\N	\N
357	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (1/10)	70.00	despesa	2025-07-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.339-04	2025-07-18 21:00:19.339-04	2025-07-19	pago	2025-07-19	10	1	\N
358	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (2/10)	70.00	despesa	2025-08-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.451-04	2025-07-18 21:00:19.451-04	2025-08-19	pendente	\N	10	2	357
359	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (3/10)	70.00	despesa	2025-09-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.467-04	2025-07-18 21:00:19.467-04	2025-09-19	pendente	\N	10	3	357
360	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (4/10)	70.00	despesa	2025-10-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.489-04	2025-07-18 21:00:19.489-04	2025-10-19	pendente	\N	10	4	357
361	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (5/10)	70.00	despesa	2025-11-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.514-04	2025-07-18 21:00:19.514-04	2025-11-19	pendente	\N	10	5	357
362	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (6/10)	70.00	despesa	2025-12-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.545-04	2025-07-18 21:00:19.545-04	2025-12-19	pendente	\N	10	6	357
363	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (7/10)	70.00	despesa	2026-01-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.575-04	2025-07-18 21:00:19.575-04	2026-01-19	pendente	\N	10	7	357
364	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (8/10)	70.00	despesa	2026-02-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.661-04	2025-07-18 21:00:19.661-04	2026-02-19	pendente	\N	10	8	357
365	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (9/10)	70.00	despesa	2026-03-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.678-04	2025-07-18 21:00:19.678-04	2026-03-19	pendente	\N	10	9	357
366	AMAZON -PRESENTES BOINE E APARELHO KARAOKE (10/10)	70.00	despesa	2026-04-19	USEI CARTAO CREDITO AMAZON- CASA BAHIA	parcelada	1	16	2025-07-18 21:00:19.695-04	2025-07-18 21:00:19.695-04	2026-04-19	pendente	\N	10	10	357
368	CICERO BET365	693.47	despesa	2025-07-19		unica	1	34	2025-07-18 21:04:16.462-04	2025-07-18 21:04:16.462-04	2025-07-19	pago	2025-07-19	\N	\N	\N
369	HERCULES (BET365)	693.47	despesa	2025-07-19	DIVISAO DE LUCRO	unica	1	34	2025-07-18 21:04:53.933-04	2025-07-18 21:04:53.933-04	2025-07-19	pago	2025-07-19	\N	\N	\N
370	BET365 - DIVISAO LUCRO	1717.00	receita	2025-07-19		unica	1	34	2025-07-18 21:05:41.184-04	2025-07-18 21:05:41.184-04	2025-07-19	a_pagar	\N	\N	\N	\N
371	Almoco - Felipe /Gabriel	72.00	despesa	2025-07-19		unica	1	12	2025-07-18 21:07:21.22-04	2025-07-18 21:07:21.22-04	2025-07-19	pago	2025-07-19	\N	\N	\N
372	Combustivel	50.00	despesa	2025-07-19		unica	1	14	2025-07-18 21:07:38.752-04	2025-07-18 21:07:38.752-04	2025-07-19	pago	2025-07-19	\N	\N	\N
373	Material Ganchos e Buchas (pago cartao credito) (1/10)	170.87	despesa	2025-07-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.086-04	2025-07-18 21:09:03.086-04	2025-07-19	pago	2025-07-19	10	1	\N
374	Material Ganchos e Buchas (pago cartao credito) (2/10)	170.87	despesa	2025-08-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.126-04	2025-07-18 21:09:03.126-04	2025-08-19	pendente	\N	10	2	373
375	Material Ganchos e Buchas (pago cartao credito) (3/10)	170.87	despesa	2025-09-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.15-04	2025-07-18 21:09:03.15-04	2025-09-19	pendente	\N	10	3	373
376	Material Ganchos e Buchas (pago cartao credito) (4/10)	170.87	despesa	2025-10-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.175-04	2025-07-18 21:09:03.175-04	2025-10-19	pendente	\N	10	4	373
377	Material Ganchos e Buchas (pago cartao credito) (5/10)	170.87	despesa	2025-11-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.202-04	2025-07-18 21:09:03.202-04	2025-11-19	pendente	\N	10	5	373
378	Material Ganchos e Buchas (pago cartao credito) (6/10)	170.87	despesa	2025-12-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.222-04	2025-07-18 21:09:03.222-04	2025-12-19	pendente	\N	10	6	373
379	Material Ganchos e Buchas (pago cartao credito) (7/10)	170.87	despesa	2026-01-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.237-04	2025-07-18 21:09:03.237-04	2026-01-19	pendente	\N	10	7	373
380	Material Ganchos e Buchas (pago cartao credito) (8/10)	170.87	despesa	2026-02-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.251-04	2025-07-18 21:09:03.251-04	2026-02-19	pendente	\N	10	8	373
381	Material Ganchos e Buchas (pago cartao credito) (9/10)	170.87	despesa	2026-03-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.27-04	2025-07-18 21:09:03.27-04	2026-03-19	pendente	\N	10	9	373
382	Material Ganchos e Buchas (pago cartao credito) (10/10)	170.87	despesa	2026-04-19	usei cartao brasil card. conta paga .	parcelada	1	10	2025-07-18 21:09:03.288-04	2025-07-18 21:09:03.288-04	2026-04-19	pendente	\N	10	10	373
383	Reforco - Heloisa (Rosaria)	200.00	despesa	2025-07-19		unica	1	16	2025-07-18 21:09:45.724-04	2025-07-18 21:09:45.724-04	2025-07-19	pago	2025-07-19	\N	\N	\N
384	Felipe Gauna	185.00	despesa	2025-07-19		unica	1	12	2025-07-18 21:10:13.058-04	2025-07-18 21:10:13.058-04	2025-07-19	pago	2025-07-19	\N	\N	\N
385	Gabriel Duque	135.00	despesa	2025-07-19		unica	1	12	2025-07-18 21:10:30.831-04	2025-07-18 21:10:30.831-04	2025-07-19	pago	2025-07-19	\N	\N	\N
\.


--
-- Data for Name: Usuarios; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public."Usuarios" (id, nome, login, senha, data_nascimento, saldo, admin, data_criacao, data_atualizacao) FROM stdin;
1	Administrador	admin	$2a$10$sZmtChI0l2QWujrdx60sceMhe14ytmbuPaCrSSeoRaI69cEmeUkFW	1989-12-31	32213.30	t	2025-06-29 17:24:49.531-04	2025-07-18 21:35:11.715-04
\.


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.categoria (id, descricao, usuario_id, data_criacao, data_atualizacao) FROM stdin;
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.categorias (id, descricao, usuario_id, data_criacao, data_atualizacao) FROM stdin;
6	Lazer	1	2025-06-30 08:42:06.475-04	2025-06-30 17:18:47.092-04
9	Outros	1	2025-06-30 08:42:06.518-04	2025-06-30 17:18:47.097-04
10	Material	1	2025-06-30 08:59:08.378-04	2025-06-30 17:18:47.102-04
11	Serviços	1	2025-06-30 10:29:33.575-04	2025-06-30 17:18:47.108-04
12	Serviços - M.Obra	1	2025-06-30 10:29:55.198-04	2025-06-30 17:18:47.112-04
13	Despesas Administrativas	1	2025-06-30 10:45:53.586-04	2025-06-30 17:18:47.121-04
14	Carro (Empresa)	1	2025-06-30 10:55:15.111-04	2025-06-30 17:18:47.124-04
15	Marketing	1	2025-06-30 11:01:35.376-04	2025-06-30 17:18:47.13-04
16	Pro-Labore	1	2025-06-30 12:27:22.469-04	2025-06-30 17:18:47.137-04
18	Produção (Uautelas)	1	2025-06-30 12:39:38.518-04	2025-06-30 17:18:47.145-04
19	Produção (HG Solucoes)	1	2025-06-30 12:39:54.071-04	2025-06-30 17:18:47.148-04
20	Moradia	1	2025-06-30 15:13:10.866-04	2025-06-30 17:18:47.152-04
21	Alimentação	1	2025-06-30 15:13:10.896-04	2025-06-30 17:18:47.157-04
22	Transporte	1	2025-06-30 15:13:10.913-04	2025-06-30 17:18:47.16-04
23	Saúde	1	2025-06-30 15:13:10.926-04	2025-06-30 17:18:47.163-04
24	Educação	1	2025-06-30 15:13:10.939-04	2025-06-30 17:18:47.171-04
25	Salário	1	2025-06-30 15:13:10.961-04	2025-06-30 17:18:47.178-04
26	Freelance	1	2025-06-30 15:13:10.98-04	2025-06-30 17:18:47.182-04
\.


--
-- Data for Name: contas; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.contas (id, nome, saldo, tipo, usuario_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: movimentacaos; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.movimentacaos (id, descricao, valor, tipo, data, observacao, tipo_frequencia, usuario_id, categoria_id, data_criacao, data_atualizacao) FROM stdin;
\.


--
-- Data for Name: movimentacoes; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.movimentacoes (id, descricao, valor, tipo, data, observacao, tipo_frequencia, status, data_vencimento, data_pagamento, valor_pago, lembrete_ativo, dias_lembrete, recorrente, parcela_atual, total_parcelas, movimentacao_pai_id, usuario_id, categoria_id, data_criacao, data_atualizacao) FROM stdin;
1	Deyu - Fabrica	4285.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	4285.00	f	3	f	1	1	\N	1	10	2025-06-30 09:00:48.38-04	2025-06-30 17:18:47.316-04
2	Deyu - Fabrica	3575.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	3575.00	f	3	f	1	1	\N	1	10	2025-06-30 09:01:26.006-04	2025-06-30 17:18:47.334-04
3	Deyu - Fabrica	5345.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	5345.00	f	3	f	1	1	\N	1	10	2025-06-30 09:01:52.96-04	2025-06-30 17:18:47.349-04
4	Deyu - Fabrica	1824.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	1824.00	f	3	f	1	1	\N	1	10	2025-06-30 09:02:20.482-04	2025-06-30 17:18:47.363-04
5	Deyu - Fabrica	4081.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	4081.00	f	3	f	1	1	\N	1	10	2025-06-30 09:02:44.653-04	2025-06-30 17:18:47.374-04
6	Deyu - Fabrica	2819.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	2819.00	f	3	f	1	1	\N	1	10	2025-06-30 09:03:57.049-04	2025-06-30 17:18:47.383-04
7	Deyu - Fabrica	4267.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	4267.00	f	3	f	1	1	\N	1	10	2025-06-30 09:55:29.518-04	2025-06-30 17:18:47.397-04
8	Metalurgica Verdadeira - Fabrica	693.00	despesa	2025-04-30 20:00:00-04	=1749,09/3 + 110	unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	693.00	f	3	f	1	1	\N	1	10	2025-06-30 09:58:30.837-04	2025-06-30 17:18:47.406-04
9	Metalurgica Verdadeira - Fabrica	583.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	583.00	f	3	f	1	1	\N	1	10	2025-06-30 09:59:12.457-04	2025-06-30 17:18:47.418-04
10	Metalurgica Verdadeira - Fabrica	583.00	despesa	2025-06-30 20:00:00-04		unica	pago	2025-06-30 20:00:00-04	2025-06-30 20:00:00-04	583.00	f	3	f	1	1	\N	1	10	2025-06-30 10:00:01.243-04	2025-06-30 17:18:47.432-04
11	Deyu - Fabrica	995.00	despesa	2025-07-24 20:00:00-04		unica	pago	2025-07-24 20:00:00-04	2025-07-24 20:00:00-04	995.00	f	3	f	1	1	\N	1	10	2025-06-30 10:00:47.149-04	2025-06-30 17:18:47.443-04
12	Deyu - Fabrica	631.00	despesa	2025-07-04 20:00:00-04		unica	pago	2025-07-04 20:00:00-04	2025-07-04 20:00:00-04	631.00	f	3	f	1	1	\N	1	10	2025-06-30 10:01:14.986-04	2025-06-30 17:18:47.455-04
13	Deyu - Fabrica	817.00	despesa	2025-07-24 20:00:00-04		unica	pago	2025-07-24 20:00:00-04	2025-07-24 20:00:00-04	817.00	f	3	f	1	1	\N	1	10	2025-06-30 10:01:40.378-04	2025-06-30 17:18:47.46-04
14	Textil - Fabrica	3070.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	3070.00	f	3	f	1	1	\N	1	10	2025-06-30 10:04:19.579-04	2025-06-30 17:18:47.466-04
15	Textil - Fabrica	8205.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	8205.00	f	3	f	1	1	\N	1	10	2025-06-30 10:04:50.484-04	2025-06-30 17:18:47.473-04
16	Textil - Fabrica	548.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	548.00	f	3	f	1	1	\N	1	6	2025-06-30 10:05:26.237-04	2025-06-30 17:18:47.482-04
17	Mauax - Fabrica	412.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	412.00	f	3	f	1	1	\N	1	10	2025-06-30 10:06:38.22-04	2025-06-30 17:18:47.489-04
18	Mauax - Fabrica	1737.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	1737.00	f	3	f	1	1	\N	1	10	2025-06-30 10:07:02.304-04	2025-06-30 17:18:47.499-04
19	Kalon Adesivas - Fabrica	181.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	181.00	f	3	f	1	1	\N	1	10	2025-06-30 10:07:43.767-04	2025-06-30 17:18:47.511-04
20	Kalon Adesivas - Fabrica	1117.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	1117.00	f	3	f	1	1	\N	1	10	2025-06-30 10:08:07.738-04	2025-06-30 17:18:47.525-04
21	Kalon Adesivas - Fabrica	181.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	181.00	f	3	f	1	1	\N	1	10	2025-06-30 10:08:33.942-04	2025-06-30 17:18:47.533-04
22	NRArtefatos - Fabrica	1404.00	despesa	2024-12-29 20:00:00-04	s/frete	unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1404.00	f	3	f	1	1	\N	1	10	2025-06-30 10:09:56.077-04	2025-06-30 17:18:47.543-04
23	NRArtefatos - Fabrica	1357.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	1357.00	f	3	f	1	1	\N	1	10	2025-06-30 10:10:19.779-04	2025-06-30 17:18:47.55-04
24	Alumetal - Distribuidora	5934.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	5934.00	f	3	f	1	1	\N	1	10	2025-06-30 10:11:13.618-04	2025-06-30 17:18:47.564-04
25	Alumetal - Distribuidora	5947.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	5947.00	f	3	f	1	1	\N	1	10	2025-06-30 10:11:34.925-04	2025-06-30 17:18:47.572-04
26	Alumetal - Distribuidora	4872.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	4872.00	f	3	f	1	1	\N	1	10	2025-06-30 10:11:56.609-04	2025-06-30 17:18:47.578-04
27	Alumetal - Distribuidora	5420.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	5420.00	f	3	f	1	1	\N	1	10	2025-06-30 10:12:16.546-04	2025-06-30 17:18:47.582-04
28	Alumetal - Distribuidora	1583.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	1583.00	f	3	f	1	1	\N	1	10	2025-06-30 10:12:41.453-04	2025-06-30 17:18:47.597-04
29	Alumetal - Distribuidora	1594.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	1594.00	f	3	f	1	1	\N	1	10	2025-06-30 10:12:59.182-04	2025-06-30 17:18:47.609-04
30	Alumetal - Distribuidora	3159.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	3159.00	f	3	f	1	1	\N	1	10	2025-06-30 10:13:19.96-04	2025-06-30 17:18:47.624-04
31	Deyu - Fabrica	770.00	despesa	2025-05-31 20:00:00-04	frete (entrega de material)	unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	770.00	f	3	f	1	1	\N	1	10	2025-06-30 10:14:51.326-04	2025-06-30 17:18:47.637-04
32	Deyu - Fabrica	497.00	despesa	2025-03-31 20:00:00-04	frete (material)	unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	497.00	f	3	f	1	1	\N	1	10	2025-06-30 10:15:34.079-04	2025-06-30 17:18:47.644-04
33	Deyu - Fabrica	934.00	despesa	2025-01-31 20:00:00-04	frete (material)	unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	934.00	f	3	f	1	1	\N	1	10	2025-06-30 10:16:10.144-04	2025-06-30 17:18:47.658-04
34	Deyu - Fabrica	195.00	despesa	2024-12-29 20:00:00-04	frete (material)	unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	195.00	f	3	f	1	1	\N	1	10	2025-06-30 10:16:29.925-04	2025-06-30 17:18:47.666-04
35	Catumbi - Fabrica	260.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	260.00	f	3	f	1	1	\N	1	10	2025-06-30 10:17:36.377-04	2025-06-30 17:18:47.683-04
36	Catumbi - Fabrica	260.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	260.00	f	3	f	1	1	\N	1	10	2025-06-30 10:17:54-04	2025-06-30 17:18:47.697-04
37	PerfilFerros - Distribuidora	399.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	399.00	f	3	f	1	1	\N	1	10	2025-06-30 10:18:59.735-04	2025-06-30 17:18:47.707-04
38	PerfilFerros - Distribuidora	2334.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	2334.00	f	3	f	1	1	\N	1	10	2025-06-30 10:19:23.067-04	2025-06-30 17:18:47.713-04
39	PerfilFerros - Distribuidora	408.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	408.00	f	3	f	1	1	\N	1	10	2025-06-30 10:19:40.924-04	2025-06-30 17:18:47.723-04
40	PerfilFerros - Distribuidora	538.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	538.00	f	3	f	1	1	\N	1	10	2025-06-30 10:20:02.743-04	2025-06-30 17:18:47.735-04
41	PerfilFerros - Distribuidora	330.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	330.00	f	3	f	1	1	\N	1	10	2025-06-30 10:20:26.156-04	2025-06-30 17:18:47.744-04
42	Pafemac - Distribuidora	120.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	120.00	f	3	f	1	1	\N	1	10	2025-06-30 10:21:31.673-04	2025-06-30 17:18:47.757-04
43	Pafemac - Distribuidora	185.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	185.00	f	3	f	1	1	\N	1	10	2025-06-30 10:21:58.216-04	2025-06-30 17:18:47.773-04
44	Pafemac - Distribuidora	283.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	283.00	f	3	f	1	1	\N	1	10	2025-06-30 10:22:25.337-04	2025-06-30 17:18:47.808-04
45	Pafemac - Distribuidora	125.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	125.00	f	3	f	1	1	\N	1	10	2025-06-30 10:22:49.44-04	2025-06-30 17:18:47.836-04
46	Juros - Mateiral	1530.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1530.00	f	3	f	1	1	\N	1	10	2025-06-30 10:24:09.691-04	2025-06-30 17:18:47.845-04
47	Juros - Mateiral	500.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	500.00	f	3	f	1	1	\N	1	10	2025-06-30 10:24:39.45-04	2025-06-30 17:18:47.85-04
48	Juros - Mateiral	465.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	465.00	f	3	f	1	1	\N	1	10	2025-06-30 10:25:01.555-04	2025-06-30 17:18:47.857-04
49	Juros - Mateiral	1084.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	1084.00	f	3	f	1	1	\N	1	10	2025-06-30 10:25:30.677-04	2025-06-30 17:18:47.866-04
50	Juros - Mateiral	213.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	213.00	f	3	f	1	1	\N	1	10	2025-06-30 10:26:18.107-04	2025-06-30 17:18:47.878-04
51	Juros - Mateiral	325.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	325.00	f	3	f	1	1	\N	1	10	2025-06-30 10:26:33.425-04	2025-06-30 17:18:47.889-04
52	Juros - Mateiral	500.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	500.00	f	3	f	1	1	\N	1	10	2025-06-30 10:26:52.457-04	2025-06-30 17:18:47.9-04
53	Felipe Gauna	4530.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	4530.00	f	3	f	1	1	\N	1	12	2025-06-30 10:30:56.541-04	2025-06-30 17:18:47.919-04
54	Felipe Gauna	5825.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	5825.00	f	3	f	1	1	\N	1	12	2025-06-30 10:31:20.669-04	2025-06-30 17:18:47.933-04
55	Felipe Gauna	6068.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	6068.00	f	3	f	1	1	\N	1	12	2025-06-30 10:31:58.925-04	2025-06-30 17:18:47.943-04
56	Felipe Gauna	4507.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	4507.00	f	3	f	1	1	\N	1	12	2025-06-30 10:32:31.328-04	2025-06-30 17:18:47.956-04
57	Felipe Gauna	3300.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	3300.00	f	3	f	1	1	\N	1	12	2025-06-30 10:32:55.314-04	2025-06-30 17:18:47.966-04
58	Felipe Gauna	3235.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	3235.00	f	3	f	1	1	\N	1	12	2025-06-30 10:33:42.506-04	2025-06-30 17:18:47.98-04
59	Felipe Gauna	2675.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	2675.00	f	3	f	1	1	\N	1	12	2025-06-30 10:34:04.508-04	2025-06-30 17:18:47.99-04
60	Gabriel Duque	1900.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	1900.00	f	3	f	1	1	\N	1	12	2025-06-30 10:37:32.629-04	2025-06-30 17:18:48-04
61	Gabriel Duque	1690.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	1690.00	f	3	f	1	1	\N	1	12	2025-06-30 10:37:59.069-04	2025-06-30 17:18:48.014-04
62	Gabriel Duque	1935.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	1935.00	f	3	f	1	1	\N	1	12	2025-06-30 10:38:19.322-04	2025-06-30 17:18:48.027-04
63	Plano Cel Uautelas	51.00	despesa	2024-11-30 20:00:00-04		parcelada	pago	2024-11-30 20:00:00-04	2024-11-30 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:46:31.863-04	2025-06-30 17:18:48.041-04
64	Plano Cel Uautelas	51.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:46:59.572-04	2025-06-30 17:18:48.063-04
65	Plano Cel Uautelas	51.00	despesa	2025-01-31 20:00:00-04		unica	pago	2025-01-31 20:00:00-04	2025-01-31 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:47:19.697-04	2025-06-30 17:18:48.084-04
66	Plano Cel Uautelas	51.00	despesa	2025-02-28 20:00:00-04		unica	pago	2025-02-28 20:00:00-04	2025-02-28 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:48:26.524-04	2025-06-30 17:18:48.107-04
67	Plano Cel Uautelas	51.00	despesa	2025-03-31 20:00:00-04		unica	pago	2025-03-31 20:00:00-04	2025-03-31 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:48:50.903-04	2025-06-30 17:18:48.129-04
68	Plano Cel Uautelas	51.00	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:49:10.613-04	2025-06-30 17:18:48.143-04
69	Plano Cel Uautelas	51.00	despesa	2025-05-31 20:00:00-04		unica	pago	2025-05-31 20:00:00-04	2025-05-31 20:00:00-04	51.00	f	3	f	1	1	\N	1	13	2025-06-30 10:49:35.411-04	2025-06-30 17:18:48.151-04
70	MEI Uautelas	292.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	292.00	f	3	f	1	1	\N	1	13	2025-06-30 10:51:19.267-04	2025-06-30 17:18:48.163-04
71	MEI Uautelas	270.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	270.00	f	3	f	1	1	\N	1	13	2025-06-30 10:51:41.306-04	2025-06-30 17:18:48.173-04
72	MEI Uautelas	52.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	52.00	f	3	f	1	1	\N	1	13	2025-06-30 10:52:03.715-04	2025-06-30 17:18:48.183-04
73	MEI Uautelas	52.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	52.00	f	3	f	1	1	\N	1	13	2025-06-30 10:52:20.029-04	2025-06-30 17:18:48.198-04
74	MEI Uautelas	276.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	276.00	f	3	f	1	1	\N	1	13	2025-06-30 10:52:48.705-04	2025-06-30 17:18:48.215-04
75	MEI Uautelas	279.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	279.00	f	3	f	1	1	\N	1	13	2025-06-30 10:53:17.011-04	2025-06-30 17:18:48.228-04
76	Carro - SomaDespesas	2852.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	2852.00	f	3	f	1	1	\N	1	14	2025-06-30 10:56:16.217-04	2025-06-30 17:18:48.232-04
77	Carro - SomaDespesas	2592.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	2592.00	f	3	f	1	1	\N	1	14	2025-06-30 10:56:51.406-04	2025-06-30 17:18:48.238-04
78	Carro - SomaDespesas	6293.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	6293.00	f	3	f	1	1	\N	1	14	2025-06-30 10:57:23.243-04	2025-06-30 17:18:48.247-04
79	Carro - SomaDespesas	4581.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	4581.00	f	3	f	1	1	\N	1	14	2025-06-30 10:58:00.462-04	2025-06-30 17:18:48.252-04
80	Carro - SomaDespesas	4934.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	4934.00	f	3	f	1	1	\N	1	14	2025-06-30 10:58:31.704-04	2025-06-30 17:18:48.258-04
81	Carro - SomaDespesas	3054.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	3054.00	f	3	f	1	1	\N	1	14	2025-06-30 10:58:55.618-04	2025-06-30 17:18:48.269-04
82	Carro - SomaDespesas	1734.00	despesa	2025-06-04 20:00:00-04	Manutenção + Combustivel	unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	1734.00	f	3	f	1	1	\N	1	14	2025-06-30 11:00:06.999-04	2025-06-30 17:18:48.273-04
83	Seguro de Vida - Sicoob	147.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	147.00	f	3	f	1	1	\N	1	15	2025-06-30 11:02:10.193-04	2025-06-30 17:18:48.277-04
84	Seguro de Vida - Sicoob	147.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	147.00	f	3	f	1	1	\N	1	15	2025-06-30 11:02:27.18-04	2025-06-30 17:18:48.282-04
85	Seguro de Vida - Sicoob	147.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	147.00	f	3	f	1	1	\N	1	15	2025-06-30 11:02:40.749-04	2025-06-30 17:18:48.288-04
86	Seguro de Vida - Sicoob	147.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	147.00	f	3	f	1	1	\N	1	15	2025-06-30 11:02:54.126-04	2025-06-30 17:18:48.292-04
87	Seguro de Vida - Sicoob	161.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	161.00	f	3	f	1	1	\N	1	15	2025-06-30 11:03:20.392-04	2025-06-30 17:18:48.298-04
88	Seguro de Vida - Sicoob	161.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	161.00	f	3	f	1	1	\N	1	15	2025-06-30 11:03:34.566-04	2025-06-30 17:18:48.305-04
89	Seguro de Vida - Sicoob	161.00	despesa	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	161.00	f	3	f	1	1	\N	1	15	2025-06-30 11:03:49.661-04	2025-06-30 17:18:48.312-04
90	MetaAds	439.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	439.00	f	3	f	1	1	\N	1	15	2025-06-30 11:05:14.073-04	2025-06-30 17:18:48.319-04
91	meta	273.00	despesa	2024-12-31 20:00:00-04		unica	pago	2024-12-31 20:00:00-04	2024-12-31 20:00:00-04	273.00	f	3	f	1	1	\N	1	15	2025-06-30 11:05:32.025-04	2025-06-30 17:18:48.33-04
92	MetaAds	124.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	124.00	f	3	f	1	1	\N	1	15	2025-06-30 11:05:52.424-04	2025-06-30 17:18:48.338-04
93	MetaAds	220.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	220.00	f	3	f	1	1	\N	1	15	2025-06-30 11:06:24.872-04	2025-06-30 17:18:48.345-04
94	MetaAds	430.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	430.00	f	3	f	1	1	\N	1	15	2025-06-30 11:06:45.296-04	2025-06-30 17:18:48.358-04
95	MetaAds	260.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	260.00	f	3	f	1	1	\N	1	15	2025-06-30 11:07:04.218-04	2025-06-30 17:18:48.37-04
96	MetaAds	71.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	71.00	f	3	f	1	1	\N	1	15	2025-06-30 11:07:19.491-04	2025-06-30 17:18:48.379-04
97	GoogleADS	1611.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1611.00	f	3	f	1	1	\N	1	15	2025-06-30 11:08:28.924-04	2025-06-30 17:18:48.389-04
98	GoogleADS	1654.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	1654.00	f	3	f	1	1	\N	1	15	2025-06-30 11:08:45.783-04	2025-06-30 17:18:48.397-04
99	GoogleADS	3519.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	3519.00	f	3	f	1	1	\N	1	15	2025-06-30 11:09:12.651-04	2025-06-30 17:18:48.405-04
100	GoogleADS	1699.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	1699.00	f	3	f	1	1	\N	1	15	2025-06-30 11:09:30.114-04	2025-06-30 17:18:48.413-04
101	GoogleADS	1390.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	1390.00	f	3	f	1	1	\N	1	15	2025-06-30 11:09:50.144-04	2025-06-30 17:18:48.423-04
102	GoogleADS	1509.43	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	1509.43	f	3	f	1	1	\N	1	15	2025-06-30 11:11:26.043-04	2025-06-30 17:18:48.435-04
103	GoogleADS	1247.69	despesa	2025-04-30 20:00:00-04		unica	pago	2025-04-30 20:00:00-04	2025-04-30 20:00:00-04	1247.69	f	3	f	1	1	\N	1	15	2025-06-30 11:11:44.958-04	2025-06-30 17:18:48.443-04
104	GoogleADS	1845.06	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	1845.06	f	3	f	1	1	\N	1	15	2025-06-30 11:12:02.772-04	2025-06-30 17:18:48.451-04
105	HospedagemSite Uautelas	42.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:13:42.916-04	2025-06-30 17:18:48.462-04
106	HospedagemSite Uautelas	42.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:14:00.04-04	2025-06-30 17:18:48.471-04
107	HospedagemSite Uautelas	42.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:14:44.012-04	2025-06-30 17:18:48.481-04
108	HospedagemSite Uautelas	42.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:15:07.3-04	2025-06-30 17:18:48.489-04
109	HospedagemSite Uautelas	42.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:15:19.252-04	2025-06-30 17:18:48.505-04
110	HospedagemSite Uautelas	42.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	6	2025-06-30 11:15:34.868-04	2025-06-30 17:18:48.52-04
111	HospedagemSite Uautelas	42.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	42.00	f	3	f	1	1	\N	1	15	2025-06-30 11:15:53.446-04	2025-06-30 17:18:48.539-04
112	Material - Outros	1549.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1549.00	f	3	f	1	1	\N	1	10	2025-06-30 11:20:09.861-04	2025-06-30 17:18:48.557-04
113	Material - Outros	1437.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	1437.00	f	3	f	1	1	\N	1	10	2025-06-30 11:21:07.046-04	2025-06-30 17:18:48.57-04
114	Material - Outros	4384.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	4384.00	f	3	f	1	1	\N	1	10	2025-06-30 11:22:04.356-04	2025-06-30 17:18:48.585-04
115	Material - Outros	2267.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	2267.00	f	3	f	1	1	\N	1	10	2025-06-30 11:22:45.378-04	2025-06-30 17:18:48.615-04
116	Material - Outros	4370.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	4370.00	f	3	f	1	1	\N	1	10	2025-06-30 11:23:27.993-04	2025-06-30 17:18:48.638-04
117	Material - Outros	2904.00	despesa	2025-05-03 20:00:00-04		unica	pago	2025-05-03 20:00:00-04	2025-05-03 20:00:00-04	2904.00	f	3	f	1	1	\N	1	10	2025-06-30 11:24:16.656-04	2025-06-30 17:18:48.647-04
118	Material - Outros	1311.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	1311.00	f	3	f	1	1	\N	1	10	2025-06-30 11:25:19.469-04	2025-06-30 17:18:48.657-04
119	M.Obra - Outros	1900.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1900.00	f	3	f	1	1	\N	1	12	2025-06-30 11:26:20.741-04	2025-06-30 17:18:48.67-04
120	M.Obra - Outros	850.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	850.00	f	3	f	1	1	\N	1	12	2025-06-30 11:26:51.511-04	2025-06-30 17:18:48.682-04
121	M.Obra - Outros	3128.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	3128.00	f	3	f	1	1	\N	1	12	2025-06-30 11:27:19.671-04	2025-06-30 17:18:48.694-04
122	M.Obra - Outros	4220.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	4220.00	f	3	f	1	1	\N	1	12	2025-06-30 11:27:46.479-04	2025-06-30 17:18:48.706-04
123	M.Obra - Outros	235.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	235.00	f	3	f	1	1	\N	1	12	2025-06-30 11:28:16.808-04	2025-06-30 17:18:48.731-04
124	M.Obra - Outros	135.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	135.00	f	3	f	1	1	\N	1	12	2025-06-30 11:28:32.227-04	2025-06-30 17:18:48.746-04
125	ADM.OUTROS	649.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	649.00	f	3	f	1	1	\N	1	13	2025-06-30 11:29:17.745-04	2025-06-30 17:18:48.76-04
126	ADM.OUTROS	1950.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	1950.00	f	3	f	1	1	\N	1	13	2025-06-30 11:29:47.503-04	2025-06-30 17:18:48.771-04
127	ADM.OUTROS	542.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	542.00	f	3	f	1	1	\N	1	13	2025-06-30 11:30:12.495-04	2025-06-30 17:18:48.778-04
128	ADM.OUTROS	679.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	679.00	f	3	f	1	1	\N	1	13	2025-06-30 11:30:32.598-04	2025-06-30 17:18:48.785-04
129	ADM.OUTROS	718.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	718.00	f	3	f	1	1	\N	1	13	2025-06-30 11:30:57.657-04	2025-06-30 17:18:48.792-04
130	ADM.OUTROS	435.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	435.00	f	3	f	1	1	\N	1	13	2025-06-30 11:31:13.976-04	2025-06-30 17:18:48.802-04
131	ADM.OUTROS	1595.00	despesa	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	1595.00	f	3	f	1	1	\N	1	13	2025-06-30 11:31:25.903-04	2025-06-30 17:18:48.815-04
132	Marketing - Outros	90.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	90.00	f	3	f	1	1	\N	1	15	2025-06-30 11:32:35.395-04	2025-06-30 17:18:48.828-04
133	Marketing - Outros	180.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	180.00	f	3	f	1	1	\N	1	15	2025-06-30 11:33:01.017-04	2025-06-30 17:18:48.843-04
134	Marketing - Outros	650.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	650.00	f	3	f	1	1	\N	1	15	2025-06-30 11:33:31.945-04	2025-06-30 17:18:48.855-04
135	Marketing - Outros	632.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	632.00	f	3	f	1	1	\N	1	15	2025-06-30 11:34:03.728-04	2025-06-30 17:18:48.864-04
136	Marketing - Outros	330.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	330.00	f	3	f	1	1	\N	1	15	2025-06-30 11:34:29.389-04	2025-06-30 17:18:48.878-04
137	Marketing - Outros	200.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	200.00	f	3	f	1	1	\N	1	15	2025-06-30 11:34:51.318-04	2025-06-30 17:18:48.893-04
138	Parcelamento - Carro	1500.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:29:04.663-04	2025-06-30 17:18:48.906-04
139	Parcelamento - Carro	1500.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:29:25.661-04	2025-06-30 17:18:48.914-04
140	Parcelamento - Carro	1500.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:29:44.049-04	2025-06-30 17:18:48.922-04
141	Parcelamento - Carro	1500.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:29:57.824-04	2025-06-30 17:18:48.931-04
142	Parcelamento - Carro	1500.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:30:17.452-04	2025-06-30 17:18:48.941-04
143	Parcelamento - Carro	1500.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:30:31.921-04	2025-06-30 17:18:48.95-04
144	Parcelamento - Carro	1500.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	14	2025-06-30 12:30:48.252-04	2025-06-30 17:18:48.963-04
145	Outras Despesas - Geral	16097.00	despesa	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	16097.00	f	3	f	1	1	\N	1	16	2025-06-30 12:34:58.574-04	2025-06-30 17:18:48.976-04
146	Outras Despesas - Geral	11590.00	despesa	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	11590.00	f	3	f	1	1	\N	1	16	2025-06-30 12:35:34.154-04	2025-06-30 17:18:48.99-04
147	Outras Despesas - Geral	11825.00	despesa	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	11825.00	f	3	f	1	1	\N	1	16	2025-06-30 12:36:01.942-04	2025-06-30 17:18:48.999-04
148	Outras Despesas - Geral	13953.00	despesa	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	13953.00	f	3	f	1	1	\N	1	16	2025-06-30 12:36:36.315-04	2025-06-30 17:18:49.01-04
149	Outras Despesas - Geral	12928.00	despesa	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	12928.00	f	3	f	1	1	\N	1	16	2025-06-30 12:36:59.941-04	2025-06-30 17:18:49.018-04
150	Outras Despesas - Geral	12622.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	12622.00	f	3	f	1	1	\N	1	16	2025-06-30 12:37:19.838-04	2025-06-30 17:18:49.03-04
151	Outras Despesas - Geral	7422.00	despesa	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	7422.00	f	3	f	1	1	\N	1	16	2025-06-30 12:38:39.351-04	2025-06-30 17:18:49.037-04
152	Serviços/Material realizados	44353.00	receita	2024-12-29 20:00:00-04		unica	pago	2024-12-29 20:00:00-04	2024-12-29 20:00:00-04	44353.00	f	3	f	1	1	\N	1	18	2025-06-30 12:40:54.919-04	2025-06-30 17:18:49.051-04
153	Serviços/Material realizados	50534.00	receita	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	50534.00	f	3	f	1	1	\N	1	18	2025-06-30 12:42:02.891-04	2025-06-30 17:18:49.063-04
154	Serviços/Material realizados	74572.00	receita	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	74572.00	f	3	f	1	1	\N	1	18	2025-06-30 12:42:44.52-04	2025-06-30 17:18:49.068-04
155	Serviços/Material realizados	56241.00	receita	2025-03-03 20:00:00-04		unica	pago	2025-03-03 20:00:00-04	2025-03-03 20:00:00-04	56241.00	f	3	f	1	1	\N	1	18	2025-06-30 12:43:30.329-04	2025-06-30 17:18:49.078-04
156	Serviços/Material realizados	2907.00	receita	2025-03-03 20:00:00-04		unica	pago	2025-03-03 20:00:00-04	2025-03-03 20:00:00-04	2907.00	f	3	f	1	1	\N	1	18	2025-06-30 12:43:56.694-04	2025-06-30 17:18:49.084-04
157	Serviços/Material realizados	19320.00	receita	2025-04-03 20:00:00-04		unica	pago	2025-04-03 20:00:00-04	2025-04-03 20:00:00-04	19320.00	f	3	f	1	1	\N	1	18	2025-06-30 12:44:20.049-04	2025-06-30 17:18:49.095-04
158	Serviços/Material realizados	7078.00	receita	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	7078.00	f	3	f	1	1	\N	1	18	2025-06-30 12:44:40.501-04	2025-06-30 17:18:49.102-04
159	Serviços/Material realizados	23679.00	receita	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	23679.00	f	3	f	1	1	\N	1	18	2025-06-30 12:45:31.455-04	2025-06-30 17:18:49.113-04
160	Serviços/Material realizados	5297.00	receita	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	5297.00	f	3	f	1	1	\N	1	18	2025-06-30 12:45:47.168-04	2025-06-30 17:18:49.128-04
161	Serviços/Material realizados	26564.00	receita	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	26564.00	f	3	f	1	1	\N	1	18	2025-06-30 12:46:16.153-04	2025-06-30 17:18:49.135-04
162	Serviços/Material realizados	4865.00	receita	2025-06-04 20:00:00-04		unica	pago	2025-06-04 20:00:00-04	2025-06-04 20:00:00-04	4865.00	f	3	f	1	1	\N	1	18	2025-06-30 12:46:42.583-04	2025-06-30 17:18:49.15-04
163	OUTRAS RENDAS	3000.00	receita	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	3000.00	f	3	f	1	1	\N	1	19	2025-06-30 12:48:19.683-04	2025-06-30 17:18:49.166-04
164	OUTRAS RENDAS	974.00	receita	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	974.00	f	3	f	1	1	\N	1	19	2025-06-30 12:48:40.311-04	2025-06-30 17:18:49.177-04
165	OUTRAS RENDAS	350.00	receita	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	350.00	f	3	f	1	1	\N	1	19	2025-06-30 12:48:59.017-04	2025-06-30 17:18:49.186-04
166	OUTRAS RENDAS	7256.00	receita	2025-04-03 20:00:00-04		unica	pago	2025-04-03 20:00:00-04	2025-04-03 20:00:00-04	7256.00	f	3	f	1	1	\N	1	18	2025-06-30 12:49:19.643-04	2025-06-30 17:18:49.194-04
167	OUTRAS RENDAS	2179.00	receita	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	2179.00	f	3	f	1	1	\N	1	19	2025-06-30 12:49:43.947-04	2025-06-30 17:18:49.199-04
168	OUTRAS RENDAS	1842.00	receita	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	1842.00	f	3	f	1	1	\N	1	19	2025-06-30 12:50:15.277-04	2025-06-30 17:18:49.211-04
169	OUTRAS RENDAS	2179.00	despesa	2025-05-04 20:00:00-04		unica	pago	2025-05-04 20:00:00-04	2025-05-04 20:00:00-04	2179.00	f	3	f	1	1	\N	1	19	2025-06-30 12:55:26.26-04	2025-06-30 17:18:49.22-04
170	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2024-12-28 20:00:00-04		unica	pago	2024-12-28 20:00:00-04	2024-12-28 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:57:33.15-04	2025-06-30 17:18:49.228-04
171	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-01-04 20:00:00-04		unica	pago	2025-01-04 20:00:00-04	2025-01-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:58:04.219-04	2025-06-30 17:18:49.237-04
172	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-02-04 20:00:00-04		unica	pago	2025-02-04 20:00:00-04	2025-02-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:58:18.785-04	2025-06-30 17:18:49.248-04
173	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-03-04 20:00:00-04		unica	pago	2025-03-04 20:00:00-04	2025-03-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:58:31.696-04	2025-06-30 17:18:49.257-04
174	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-04-04 20:00:00-04		unica	pago	2025-04-04 20:00:00-04	2025-04-04 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:58:44.51-04	2025-06-30 17:18:49.265-04
175	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-05-05 20:00:00-04		unica	pago	2025-05-05 20:00:00-04	2025-05-05 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:58:58.664-04	2025-06-30 17:18:49.27-04
176	OUTRAS RENDAS (PAGAR CARRO)	1500.00	receita	2025-06-03 20:00:00-04		unica	pago	2025-06-03 20:00:00-04	2025-06-03 20:00:00-04	1500.00	f	3	f	1	1	\N	1	19	2025-06-30 12:59:11.869-04	2025-06-30 17:18:49.274-04
179	Deyu - Fabrica	994.62	despesa	2025-06-29 20:00:00-04	a pagar*	unica	pendente	2025-07-24 20:00:00-04	\N	\N	t	1	f	\N	\N	\N	1	10	2025-06-30 16:15:18.856-04	2025-06-30 17:18:49.28-04
180	Deyu - Fabrica	631.00	despesa	2025-06-29 20:00:00-04		unica	pendente	2025-07-04 20:00:00-04	\N	\N	t	1	f	\N	\N	\N	1	10	2025-06-30 16:16:39.999-04	2025-06-30 17:18:49.288-04
181	Deyu - Fabrica	817.00	despesa	2025-06-29 20:00:00-04		unica	pendente	2025-07-24 20:00:00-04	\N	\N	t	1	f	\N	\N	\N	1	10	2025-06-30 16:17:30.901-04	2025-06-30 17:18:49.298-04
182	Deyu - Fabrica	631.00	despesa	2025-06-29 20:00:00-04		unica	pendente	2025-08-04 20:00:00-04	\N	\N	t	1	f	\N	\N	\N	1	10	2025-06-30 16:19:16.339-04	2025-06-30 17:18:49.308-04
183	Deyu - Fabrica	1550.00	despesa	2025-06-29 20:00:00-04		unica	pendente	2025-09-04 20:00:00-04	\N	\N	f	3	f	\N	\N	\N	1	10	2025-06-30 16:19:56.874-04	2025-06-30 17:18:49.319-04
177	AJUSTE DE CONTA	34663.00	despesa	2025-06-29 20:00:00-04		unica	pendente	\N	\N	\N	f	3	f	\N	\N	\N	1	13	2025-07-01 08:36:13.718-04	2025-07-01 08:36:13.718-04
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: herculesgobbi
--

COPY public.usuarios (id, nome, login, senha, data_nascimento, saldo, admin, data_criacao, data_atualizacao) FROM stdin;
1	Administrador	admin	$2b$10$jZsTzVdLsO7QdkWu.1tJvuxyNlmEYq.b1GoS1e1H9WLuIWhu.Xrsi	1989-12-30 21:00:00-03	34640.82	t	2025-06-29 17:24:49.531-04	2025-07-01 08:43:41.482-04
\.


--
-- Name: Categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public."Categoria_id_seq"', 34, true);


--
-- Name: Movimentacaos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public."Movimentacaos_id_seq"', 386, true);


--
-- Name: Usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public."Usuarios_id_seq"', 1, true);


--
-- Name: categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.categoria_id_seq', 1, false);


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.categorias_id_seq', 1, false);


--
-- Name: contas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.contas_id_seq', 1, false);


--
-- Name: movimentacaos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.movimentacaos_id_seq', 1, false);


--
-- Name: movimentacoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.movimentacoes_id_seq', 13, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: herculesgobbi
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: Categoria Categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Categoria"
    ADD CONSTRAINT "Categoria_pkey" PRIMARY KEY (id);


--
-- Name: Movimentacaos Movimentacaos_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Movimentacaos"
    ADD CONSTRAINT "Movimentacaos_pkey" PRIMARY KEY (id);


--
-- Name: Usuarios Usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Usuarios"
    ADD CONSTRAINT "Usuarios_pkey" PRIMARY KEY (id);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: contas contas_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.contas
    ADD CONSTRAINT contas_pkey PRIMARY KEY (id);


--
-- Name: movimentacaos movimentacaos_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacaos
    ADD CONSTRAINT movimentacaos_pkey PRIMARY KEY (id);


--
-- Name: movimentacoes movimentacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_login_key; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_login_key UNIQUE (login);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: Categoria Categoria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Categoria"
    ADD CONSTRAINT "Categoria_usuario_id_fkey" FOREIGN KEY (usuario_id) REFERENCES public."Usuarios"(id);


--
-- Name: Movimentacaos Movimentacaos_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Movimentacaos"
    ADD CONSTRAINT "Movimentacaos_categoria_id_fkey" FOREIGN KEY (categoria_id) REFERENCES public."Categoria"(id);


--
-- Name: Movimentacaos Movimentacaos_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public."Movimentacaos"
    ADD CONSTRAINT "Movimentacaos_usuario_id_fkey" FOREIGN KEY (usuario_id) REFERENCES public."Usuarios"(id);


--
-- Name: movimentacaos movimentacaos_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacaos
    ADD CONSTRAINT movimentacaos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categoria(id) ON UPDATE CASCADE;


--
-- Name: movimentacaos movimentacaos_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacaos
    ADD CONSTRAINT movimentacaos_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE;


--
-- Name: movimentacoes movimentacoes_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: movimentacoes movimentacoes_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: herculesgobbi
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

